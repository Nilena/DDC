import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


import { PackageListingComponent } from './Components/package-listing/package-listing.component';
import {NgxPaginationModule} from 'ngx-pagination';
import { ScanNewComponent } from './Components/scan-new/scan-new.component';
import { SharedModule } from '../shared/shared.module';
import { SignAndPrintComponent } from './Components/sign-and-print/sign-and-print.component';
import { NotifyInternalPackageComponent } from './Components/notify-internal-package/notify-internal-package.component';
import { UnsavedChangesGuard } from '../core/Guards/unsaved-changes.guard';

const routes: Routes =[{
  path:'listing', component: PackageListingComponent
},
{
  path:'scan-new', component: ScanNewComponent,canDeactivate : [UnsavedChangesGuard]
},
{
  path:'', redirectTo:'scan-new'
}
 ];
@NgModule({
  declarations: [
    PackageListingComponent,
    ScanNewComponent,
    SignAndPrintComponent,
    NotifyInternalPackageComponent,
  ],
  imports: [
    CommonModule,
    SharedModule,
    NgxPaginationModule,
    FormsModule,
    SharedModule,
    ReactiveFormsModule,
    RouterModule.forChild(routes)
  ],
})
export class PackageModule { }
