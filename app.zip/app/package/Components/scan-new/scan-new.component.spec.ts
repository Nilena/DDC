import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ScanNewComponent } from './scan-new.component';

describe('ScanNewComponent', () => {
  let component: ScanNewComponent;
  let fixture: ComponentFixture<ScanNewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ScanNewComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ScanNewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
