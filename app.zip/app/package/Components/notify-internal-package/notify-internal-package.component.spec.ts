import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NotifyInternalPackageComponent } from './notify-internal-package.component';

describe('NotifyInternalPackageComponent', () => {
  let component: NotifyInternalPackageComponent;
  let fixture: ComponentFixture<NotifyInternalPackageComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NotifyInternalPackageComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NotifyInternalPackageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
