import { Component, OnInit, Output, EventEmitter, Input, AfterViewInit } from '@angular/core';
import { PackageService } from '../../Services/package.service';
import { LoaderService } from 'src/app/core/Services/loader.service';
import { PackagesPayaload } from 'src/app/core/Models/Interfaces/package';
import { HttpErrorResponse } from '@angular/common/http';
import { AlertandtoasterService } from 'src/app/shared/Services/alertandtoaster.service';

@Component({
  selector: 'app-notify-internal-package',
  templateUrl: './notify-internal-package.component.html',
  styleUrls: ['./notify-internal-package.component.css']
})
export class NotifyInternalPackageComponent implements OnInit, AfterViewInit {

  @Output() closeNotifyInternalPackage: EventEmitter<boolean> = new EventEmitter<boolean>();
  // @Output() openInternalPackage: EventEmitter<boolean> = new EventEmitter<boolean>();
  // @Output() fromIntenalPackage: EventEmitter<boolean> = new EventEmitter<boolean>();
  showSlider: boolean = false;
  @Input() data!: PackagesPayaload;
  showCommentSlider: boolean = false;
  commentSliderLabel: string = '';
  commentSliderIcon: string = '';
  viewCommentsSection!: boolean;
  showEmailSection!: boolean;
  ViewchannelSection!: boolean;
  showNotificationSection!: boolean;
  fromIntenalPackage: boolean = true;
  commentSliderData!: { trackingNumber: string, trackingId: number; channelObj: any; };
  intakeData: any[] = [];
  constructor(private packageService: PackageService,
    private loaderService: LoaderService,
    private alertandToast: AlertandtoasterService) { }

  ngOnInit(): void {
    this.getInternalPackage(this.data.inTakeId);
  }

  ngAfterViewInit() {
    setTimeout(() => {
      this.showSlider = true;
    });
  }

  /*
   * @Desc   : Get internal package data. 
   * @Author : Abhiram M Sajeev
   */
  getInternalPackage(intakeId: number): void {
    this.loaderService.isContentLoader(true);
    this.packageService.getInternalPackage(intakeId).subscribe(res => {
      if (res.success) {
        this.intakeData = res.data.trackings;
      }
      this.loaderService.isContentLoader(false);
    }, (error: HttpErrorResponse) => {
      this.loaderService.isLoaderEnable(false);
      this.apiHttpErrorHandler(error);
    }
    )
  }
  /*
   * @desc : Dispaly toaster message http error 
   * @author Manaf
   */

  apiHttpErrorHandler(err: HttpErrorResponse) {
    this.alertandToast.alert.toast({
      title: 'Error',
      type: 'error',
      message: err.message,
    });
  }

  /*
   * @Desc   : close the notify internal package
   * @Author : Abhiram M Sajeev
   */
  close() {

    setTimeout(() => {
      this.closeNotifyInternalPackage.emit(false);
    },200);
    this.showSlider = false;
  }

  /*
   * @Desc   : Open notify modal
   * @Author : Abhiram M Sajeev
   */
  openNotify() {
    this.showCommentSlider = true
    this.close();
  }

  commentSliderToggle(value: boolean) {
    this.showCommentSlider = value;
  }

  /*
   * @Desc   : Back to the intenal package list screen
   * @Author : Abhiram M Sajeev
   */
  backToNotifyFunc() {
    this.showCommentSlider = false;
    this.getInternalPackage(this.data.inTakeId);
  }

  /*
   * @Desc   : Sending data to comments/notify slider component. 
   * @Author : Arjun S
   * @Param  : Pass in the scanned items array of datatype scannedItems.
   */
  commentSlider(item: any, isComment: boolean) {

    this.commentSliderLabel = isComment ? 'Comments' : 'Notify';
    this.commentSliderIcon = isComment ? 'comments' : 'notify';
    this.viewCommentsSection = isComment ? true : false;
    this.showEmailSection = isComment ? false : true;
    this.ViewchannelSection = isComment ? false : true;
    this.showNotificationSection = isComment ? false : true;

    const obj = {
      'trackingNumber': item.trackingNumber,
      'trackingId': item.trackId,
      'channelObj': item.channels
    }
    if (obj) {
      this.commentSliderData = obj;
    }
    this.commentSliderToggle(true);
  }
}
