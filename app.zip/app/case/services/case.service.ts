import { Injectable } from '@angular/core';
import { getApiUrl, apiList } from 'src/app/core/Constants/apilist';
import { ApiResponse } from 'src/app/core/Models/Interfaces/commonInterface';
import { HttpClient } from '@angular/common/http';
import { forkJoin } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class CaseService {
  constructor(private http: HttpClient) { }

  /*
  auth: Nilena Alexander
  desc: to get testedPartyrRoles
  */
  getTestPartyRoles() {
    let endpoint =
      getApiUrl(apiList.case.getTestPartyRoles) + `?pageNo=1&pageSize=100`;
    return this.http.get<ApiResponse>(endpoint);
  }

  /*
   auth: Elizabeth Mathew
   desc: to get languages
   */
  getLanguages(obj: any) {
    let temp = this.objectToURLParam(obj);
    let endpoint = getApiUrl(apiList.case.languages) + `?` + temp;
    return this.http.get<ApiResponse>(endpoint);
  }
  /*
  auth : Elizabeth Mathew
  desc : to get channels
  */
  getChannelListing() {
    let endpoint = getApiUrl(apiList.package.getChannels);
    return this.http.get<ApiResponse>(endpoint);
  }

  /*
 auth : Elizabeth Mathew
 desc : to get channels
 */
  getChannelListingRegular() {
    let endpoint = getApiUrl(apiList.package.getChannels + '?channelType=regular');
    return this.http.get<ApiResponse>(endpoint);
  }

  getStateListing(
    stateName: string,
    statePageNo: number,
    statePageSize: number
  ) {
    let endpoint =
      getApiUrl(apiList.case.states) +
      `?stateName=` +
      stateName +
      `&pageNo=` +
      statePageNo +
      `&pageSize=` +
      statePageSize;
    return this.http.get<ApiResponse>(endpoint);
  }
  /*
   auth: Elizabeth Mathew
   desc: to get languages
   */

  getAgencyListing(
    stateId?: number,
    agencyName?: string,
    agencyPageNo?: number,
    agencypageSize?: number
  ) {
    let endpoint = getApiUrl(apiList.case.agencies);
    endpoint = endpoint + `?stateId=` + stateId + `&agencyName=` +
      agencyName + `&pageNo=` + agencyPageNo + `&pageSize=` + agencypageSize;
    return this.http.get<ApiResponse>(endpoint);
  }

  /*
   auth: Elizabeth Mathew
   desc: to get languages
   */
  gettestTypeListing(test: number, testpage: number) {
    let endpoint = getApiUrl(apiList.case.testTypes) + `?pageNo=` + testpage;
    return this.http.get<ApiResponse>(endpoint);
  }
  /*
   auth: Elizabeth Mathew
   desc: to get languages
   */

  getadditionalTestListing() {
    let endpoint = getApiUrl(apiList.case.additionalTest);
    return this.http.get<ApiResponse>(endpoint);
  }
  /*
     auth: Elizabeth Mathew
     desc: to get languages
     */
  forkJoinData(api: Array<any>) {
    return forkJoin(api);
  }
  /*
   auth: Elizabeth Mathew
   desc: to get languages
   */
  getSubCategoryData(id: number, pageNo: number, pageSize: number) {
    let endpoint = getApiUrl(apiList.case.subcategory);
    endpoint =
      endpoint + `/` + id + `?pageNo=` + pageNo + `&pageSize=` + pageSize;
    return this.http.get<ApiResponse>(endpoint);
  }
  /*
   auth: Elizabeth Mathew
   desc: to get languages
   */

  getTatListing(agencyId: number) {
    let endpoint = getApiUrl(apiList.case.tatMasters);
    endpoint = endpoint + `?agencyId=` + agencyId;
    return this.http.get<ApiResponse>(endpoint);
  }

  /*
   * @Desc   : Pass objects into this function to get query params 
          with object key values as result
   * @Author : Arjun S
   * @Param  : Pass in object
   */

  objectToURLParam(obj: any): string {
    let param = '';
    for (const key in obj) {
      if (encodeURIComponent(obj[key]) !== 'undefined') {
        if (encodeURIComponent(obj[key]) !== 'null') {
          if (obj.hasOwnProperty(key)) {
            if (param !== '') {
              param += '&';
            }
            param += key + '=' + encodeURIComponent(obj[key]);
          }
        }
      }
    }
    return param;
  }

  /*
   * @Desc   : Case listing API
   * @Author : Arjun S
   * @Param  : QS - pageno, pagesize, csId, refNo, name, dob
   */
  getCaseLisitngsData(pageNo: number, pageSize: number, csId?: number, refNo?: string, name?: string, dob?: string) {
    let obj = {
      pageNo: pageNo,
      pageSize: pageSize,
      csId: csId,
      refNo: refNo,
      name: name,
      dob: dob,
      srhTyp: 'qs',
    };
    let temp = this.objectToURLParam(obj);
    let endpoint = getApiUrl(apiList.case.cases);
    endpoint = endpoint + `?` + temp;
    return this.http.get<ApiResponse>(endpoint);
  }


  /*
   * @Desc   : Case listing API for advanced Search.
   * @Author : Arjun S
   * @Param  : QS - pageno, pagesize, advanced Search request
   */
  getCaseLisitngsDataAdvancedSearch(pageNo: number, pageSize: number, advSchReq: any) {
    let obj = {
      pageNo: pageNo,
      pageSize: pageSize,
      advSchReq: advSchReq,
      srhTyp: 'as',
    };
    let temp = this.objectToURLParam(obj);
    let endpoint = getApiUrl(apiList.case.cases);
    endpoint = endpoint + `?` + temp;
    return this.http.get<ApiResponse>(endpoint);
  }

  /*
   auth: Elizabeth Mathew
   desc: to get languages
   */

  getUserData() {
    let endpoint = getApiUrl(apiList.package.getUsersdata);
    return this.http.get<ApiResponse>(endpoint);
  }

  /*
   * @Desc   : to get details of case
   * @Author : Nilena Alexander
   * @Param  : case detail id
   */
  getCaseDetails(id: number) {
    let endpoint = getApiUrl(apiList.case.cases) + `/${id}`;
    return this.http.get<ApiResponse>(endpoint);
  }

  /*
   * @Desc   : to get details of collector Site
   * @Author : Nilena Alexander
   * @Param  : ageency name ,zip, page no and pagesize
   */
  getCollectorSite(obj: {}) {
    let temp = this.objectToURLParam(obj);
    let endpoint = getApiUrl(apiList.case.collectionSites) + `?` + temp;
    return this.http.get<ApiResponse>(endpoint);
  }


  /*
   auth: Elizabeth Mathew
   desc: to get languages
   */
  getSampleTypes() {
    let endpoint = getApiUrl(apiList.case.sampleTypes);
    return this.http.get<ApiResponse>(endpoint);
  }



  getTestPartyRace(obj: {}) {
    let temp = this.objectToURLParam(obj);
    let endpoint =
      getApiUrl(apiList.case.testPartyRace) + `?` + temp;
    return this.http.get<ApiResponse>(endpoint);
  }
  /*
   * @Desc   : to get details of collector Site
   * @Author : Nilena Alexander
   * @Param  : ageency name , page no and pagesize
   */
  collectorAgents(obj: {}) {
    let temp = this.objectToURLParam(obj);
    let endpoint = getApiUrl(apiList.case.collectorAgents) + `?` + temp;
    return this.http.get<ApiResponse>(endpoint);
  }

  /* @Desc   : to get details of documenttyped
  * @Author : Nilena Alexander
  * @Param  :  name , page no and pagesize
  */
  getDocumentTypes(obj: {}) {
    let temp = this.objectToURLParam(obj);
    let endpoint = getApiUrl(apiList.case.documentTypes) + `?` + temp;
    return this.http.get<ApiResponse>(endpoint);
  }


  createNewCase(req: any) {
    let url = getApiUrl(apiList.case.cases);
    return this.http.post<ApiResponse>(url, req);
  }
  /*
   * @Desc   : to upload doc
   * @Author : Nilena Alexander
   * @Param  :doc Obj
   */
  uploadDocument(obj: any) {
    let endpoint = getApiUrl(apiList.case.uploadDoc)
    return this.http.post<ApiResponse>(endpoint, obj);
  }

  /*
  * @Desc   : to upload doc
  * @Author : Nilena Alexander
  * @Param  :doc Obj
  */
  getCaseList(obj: any) {
    let temp = this.objectToURLParam(obj);
    let endpoint = getApiUrl(apiList.case.uploadDoc) + '?' + temp;
    return this.http.get<ApiResponse>(endpoint);
  }

  /*
 * @Desc   : to upload doc
 * @Author : Nilena Alexander
 * @Param  :doc Obj
 */
  deleteDoc(id: number) {
    let endpoint = getApiUrl(apiList.case.uploadDoc) + `/${id}`;
    return this.http.delete<ApiResponse>(endpoint);
  }
  /*
   * @Desc   : to upload doc
   * @Author : Nilena Alexander
   * @Param  :doc id
   */
  doumentDetails(id: number, path: string, obj?: {}) {
    let endpoint;
    if (obj) {
      let temp = this.objectToURLParam(obj);
      endpoint = getApiUrl(apiList.case.uploadDoc) + `/${id}` + '/' + path + '?' + temp;
    }
    else {
      endpoint = getApiUrl(apiList.case.uploadDoc) + `/${id}` + '/' + path;
    }

    return this.http.get<ApiResponse>(endpoint);
  }
  /*
   * @Desc   : to upload doc
   * @Author : Nilena Alexander
   * @Param  :doc id
   */
  doumentPreview(id: number) {
    let endpoint = getApiUrl(apiList.case.uploadDoc) + `/${id}`;
    return this.http.get<ApiResponse>(endpoint);
  }
  /*
   * @Desc   : to post comments
   * @Author : Nilena Alexander
   * @Param  :doc id
   */
  addingComments(obj: {}) {
    let endpoint = getApiUrl(apiList.case.comments);
    return this.http.post<ApiResponse>(endpoint, obj);
  }


  getDeliveryAgencyListing(agencyId: any) {
    let endpoint = getApiUrl(apiList.case.agencies) + `/` + agencyId;
    return this.http.get<ApiResponse>(endpoint);

  }
  /*
     * @Desc   : to post edited doc
     * @Author : Nilena Alexander
     * @Param  :doc id
     */

  updateDoc(obj:{}) {
    let endpoint = getApiUrl(apiList.case.uploadDoc);
    return this.http.put<ApiResponse>(endpoint, obj);
    }
}


