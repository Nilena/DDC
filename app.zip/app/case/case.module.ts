import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Routes, RouterModule } from '@angular/router';

import { SharedModule } from '../shared/shared.module';

import { SearchListingComponent } from './component/search-listing/search-listing.component';
import { SearchInputsComponent } from './component/search-inputs/search-inputs.component';
import { NewCaseComponent } from './component/new-case/new-case.component';
import { DocumentUploadComponent } from './component/document-upload/document-upload.component';
import { CollectorNameSelectorComponent } from './component/collector-name-selector/collector-name-selector.component';
import { CollectionSiteSelectorComponent } from './component/collection-site-selector/collection-site-selector.component';
import { NgxFileDropModule } from 'ngx-file-drop';
import { CaseDetailsComponent } from './component/case-details/case-details.component';
import {NgxPaginationModule} from 'ngx-pagination';
import { DeliveryPreferenceComponent } from './component/delivery-preference/delivery-preference.component';
import { DocumentPreviewComponent } from './component/document-preview/document-preview.component';
import { CaseSideTabComponent } from './component/case-side-tab/case-side-tab.component';
import { AccountInfoComponent } from './component/account-info/account-info.component';


const routes: Routes = [
  {
    path: 'search-listing', component: SearchListingComponent,
  }, 
  {
    path:'new-case',component:NewCaseComponent
  },
  {
    path:'details/:id',component: CaseDetailsComponent
  },
  {
    path:'delivery-preference',component: DeliveryPreferenceComponent
  },
  {
    path: '', redirectTo: 'search-listing'
  },
]


@NgModule({
  declarations: [
    SearchListingComponent,
    SearchInputsComponent,
    NewCaseComponent,
    DocumentUploadComponent,
    CollectorNameSelectorComponent,
    CollectionSiteSelectorComponent,
    CaseDetailsComponent,
    DeliveryPreferenceComponent,
    DocumentPreviewComponent,
    CaseSideTabComponent,
    AccountInfoComponent,
    ],
  imports: [
    CommonModule,
    SharedModule,
    NgxPaginationModule,
    NgxFileDropModule,
    RouterModule.forChild(routes)
  ]
})
export class CaseModule { }
