import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit, Input, Output, EventEmitter, HostListener, ViewChild, ElementRef } from '@angular/core';
import { AbstractControl, FormControl, FormGroup, Validators, ValidatorFn, ValidationErrors } from '@angular/forms';
import { CaseService } from 'src/app/case/services/case.service';
import { AdditionalTest, Agencies, CollectionAgent, CollectionSites, Languages, PaginationDetails, QuickSearchData, SampleType, States, TestPartyRaces, TestType } from 'src/app/core/Models/Interfaces/case';
import { Channels, TestSubCategories, UserPayload } from 'src/app/core/Models/Interfaces/package';
import { LoaderService } from 'src/app/core/Services/loader.service';
import { AlertandtoasterService } from 'src/app/shared/Services/alertandtoaster.service';
import * as moment from 'moment';
import { CustomValidation } from 'src/app/shared/Utilities/custom-validator';
import { CONSTANTS } from 'src/app/core/Constants/constants';
import { UtilityService } from 'src/app/shared/Services/utility.service';

@Component({
  selector: 'app-search-inputs',
  templateUrl: './search-inputs.component.html',
  styleUrls: [
    './search-inputs.component.css',
    '../../../../assets/style/css/case.css',
    '../../../../assets/style/css/accordion.css',
  ]
})
export class SearchInputsComponent implements OnInit {

  @ViewChild('CaseNoQs') CaseNoQs!: ElementRef;
  public mask = {
    guide: true,
    showMask: true,
    // keepCharPositions : true,
    mask: [/\d/, /\d/, '/', /\d/, /\d/, '/', /\d/, /\d/, /\d/, /\d/]
  };

  @HostListener('keydown', ['$event'])
  clickarrowx(event: any) {
    if (event.code === 'Enter' || event.key === 'Enter') {
      event.preventDefault();
    }
  }


  // FILTER AND COLLAPSE 
  @Input() set setView(value: boolean) {
    this.collapseFilter = !this.collapseFilter;
  }
  tabView: number = 1;
  collapseFilter!: boolean;
  advancedFilterApplied: boolean = false;

  today = new Date();
  @ViewChild('tabWindow') tabWindow!: ElementRef;

  @Output()
  quickSearchDataToParent: EventEmitter<QuickSearchData> = new EventEmitter<QuickSearchData>();
  @Output()
  clearData: EventEmitter<boolean> = new EventEmitter<boolean>();
  quickSearchDataFromLS !: QuickSearchData;

  @Output()
  AdvancedSearchDataToParent: EventEmitter<any> = new EventEmitter<any>();

  public quickSearchForm: FormGroup;
  quickSearchData!: QuickSearchData;

  public advSearchForm: FormGroup;
  advSearchData: any;
  advcancedSearchObj: any;
  advS2: any;
  setItems: any[] = [];
  // CSS expand and collapse
  caseDetails: boolean = false;
  expDateField: boolean = true;
  expReport: boolean = true;
  expPayment: boolean = true;
  expTestedParty: boolean = true;
  pagination: PaginationDetails = {
    pageNo: 1,
    pageSize: 100,
    totalPages: 1,
  };
  // Arrays 
  channelArrayList: Channels[] = []; //ONLOAD
  testTypeData: TestType[] = []; //ONLOAD
  additionalTestingArray: AdditionalTest[] = []; //ONLOAD 
  languageArrayList: Languages[] = []; //ONLOAD
  stateArrayList: States[] = []; //ONLOAD
  userArrayList: UserPayload[] = []; //ONLOAD
  raceTypeArray: TestPartyRaces[] = []; //ONLOAD
  collectionSiteArrayList: CollectionSites[] = []; //ONLOAD
  collectionAgentArrayList: CollectionAgent[] = [] //ONLOAD
  agencyArrayList: Agencies[] = [];
  subCategoryArrayList: TestSubCategories[] = [];
  tatTypeArrayList: any = [];
  tatTime: any[] = [];
  sampleType: SampleType[] = [];
  channelTypeList = CONSTANTS.channelTypeList;


  AgencyPerpage: number = 100;
  AgencyNum: number = 1;
  StatePerpage: number = 10;
  StateNum: number = 1;
  testTypePageNo: number = 1;
  testTypePageSize: number = 20;


  constructor(
    private loaderService: LoaderService,
    private caseService: CaseService,
    private alertandtoaster: AlertandtoasterService,
    private utility: UtilityService
  ) {
    this.quickSearchForm = new FormGroup({
      caseNo: new FormControl(null, Validators.compose([CustomValidation.onlyNumber])),
      referenceNo: new FormControl(null),
      testedParty: new FormControl(null),
      dob: new FormControl(null, Validators.compose([CustomValidation.futureDate,
      CustomValidation.OldDate]))
    }, Validators.compose([this.checkForAllNullData()])
    );

    this.advSearchForm = new FormGroup({

      // 1.CASE DETAIILS - (11 FIELDS)
      channelId: new FormControl(null), //BE
      stateId: new FormControl(null), //BE
      agencyId: new FormControl(null), //BE
      authenticationCode: new FormControl(null), //BE
      agencyCaseNo: new FormControl(null), //BE
      docketNo: new FormControl(null), //BE
      testTypeId: new FormControl(null), //BE
      testTypeSubCategoryId: new FormControl(null), //BE
      additionalTestId: new FormControl(null), //BE
      tatId: new FormControl(null), //BE
      chain: new FormControl(null), // BE

      // 2.DATES - (15 FIELDS) (25 FIELDS)
      caseCreatedStartDate: new FormControl(null, Validators.compose([CustomValidation.futureDate,
      CustomValidation.OldDate])), //BE
      caseCreatedEndDate: new FormControl(null, Validators.compose([CustomValidation.futureDate,
      CustomValidation.OldDate])), //BE

      caseCreatedBy: new FormControl(null), //BE

      sampleReceivedStartDate: new FormControl(null, Validators.compose([
        CustomValidation.futureDate, CustomValidation.OldDate])), //BE
      sampleReceivedEndDate: new FormControl(null, Validators.compose([
        CustomValidation.futureDate, CustomValidation.OldDate])), //BE

      dueStartDate: new FormControl(null, Validators.compose([
        CustomValidation.futureDate, CustomValidation.OldDate])), //BE
      dueEndDate: new FormControl(null, Validators.compose([
        CustomValidation.futureDate, CustomValidation.OldDate])), //BE 


      accessionedStartDate: new FormControl(null, Validators.compose([
        CustomValidation.futureDate, CustomValidation.OldDate])),
      accessionedEndDate: new FormControl(null, Validators.compose([
        CustomValidation.futureDate, CustomValidation.OldDate])),
      accessionedBy: new FormControl(null),

      qcStartDate: new FormControl(null, Validators.compose([
        CustomValidation.futureDate, CustomValidation.OldDate])), //BE
      qcEndDate: new FormControl(null, Validators.compose([
        CustomValidation.futureDate, CustomValidation.OldDate])), //BE
      qcBy: new FormControl(null), //BE

      auditedStartDate: new FormControl(null, Validators.compose([
        CustomValidation.futureDate, CustomValidation.OldDate])), //BE
      auditedEndDate: new FormControl(null, Validators.compose([
        CustomValidation.futureDate, CustomValidation.OldDate])), //BE
      auditedBy: new FormControl(null), // BE

      testedOnStartDate: new FormControl(null, Validators.compose([
        CustomValidation.futureDate, CustomValidation.OldDate])),
      testedOnEndDate: new FormControl(null, Validators.compose([
        CustomValidation.futureDate, CustomValidation.OldDate])),

      analysedOnStartDate: new FormControl(null, Validators.compose([
        CustomValidation.futureDate, CustomValidation.OldDate])),
      analysedOnEndDate: new FormControl(null, Validators.compose([
        CustomValidation.futureDate, CustomValidation.OldDate])),

      directorSoStartDate: new FormControl(null, Validators.compose([
        CustomValidation.futureDate, CustomValidation.OldDate])), //BE
      directorSoEndDate: new FormControl(null, Validators.compose([
        CustomValidation.futureDate, CustomValidation.OldDate])), //BE


      closedStartDate: new FormControl(null), //BE
      closedEndDate: new FormControl(null), //BE
      closedBy: new FormControl(null), //BE

      // 3.REPORT REQUIREMENTS - (3 FIELDS)
      language: new FormControl(null),
      emboss: new FormControl(null), //BE
      affidavit: new FormControl(null), //BE

      //4. PAYEMENT DETAILS - (2 FIELDS)
      billingType: new FormControl(null), //BE
      courtOrder: new FormControl(null), //BE


      // 5.TESTED PARTY DETAILS - (14 FIELDS) (16)
      sampleId: new FormControl(null, Validators.compose([CustomValidation.onlyNumber])), //BE
      // sampleRecord: new FormControl(null),
      allSampleReceivedStartDate: new FormControl(null, Validators.compose([
        CustomValidation.futureDate, CustomValidation.OldDate])),
      allSampleReceivedEndDate: new FormControl(null, Validators.compose([
        CustomValidation.futureDate, CustomValidation.OldDate])),
      sampleType: new FormControl(null),
      name: new FormControl(null),
      aka: new FormControl(null),
      deceased: new FormControl(null), //BE
      gender: new FormControl(null), // BE
      ssn: new FormControl(null), //BE
      raceId: new FormControl(null), //BE

      collectionStartDate: new FormControl(null, Validators.compose([CustomValidation.futureDate, CustomValidation.OldDate])), //BE
      collectionEndDate: new FormControl(null, Validators.compose([CustomValidation.futureDate, CustomValidation.OldDate])), //BE


      collectionAgentId: new FormControl(null), //BE
      collectionSiteId: new FormControl(null), //BE
      extPartyIdentifier: new FormControl(null), //BE
      // airbill: new FormControl(null),

    }, Validators.compose([this.checkForAllNullDataAdvSearch()])
    );
  }

  /*
   * @Desc   : Check for null data in form
   * @Author : Arjun S
   * @Param  : Nill
   */

  private checkForAllNullData(): ValidatorFn {
    return (formGroup: AbstractControl): ValidationErrors | null => {
      let caseNo = formGroup.get('caseNo')?.value;
      let referenceNo = formGroup.get('referenceNo')?.value;
      let testedParty = formGroup.get('testedParty')?.value;
      let dob = formGroup.get('dob')?.value;

      if ((caseNo === null || caseNo === "") &&
        (referenceNo === null || referenceNo === "") &&
        (testedParty === null || testedParty === "") &&
        (dob === null || dob === "")) {
        return { allFieldsNull: true }
      }
      return null;
    }
  }

  private checkForAllNullDataAdvSearch(): ValidatorFn {
    return (formGroup: AbstractControl): ValidationErrors | null => {
      if ((formGroup.get('channelId')?.value === null) &&
        (formGroup.get('stateId')?.value === null) &&
        (formGroup.get('agencyId')?.value === null) &&
        (formGroup.get('testTypeId')?.value === null) &&
        (formGroup.get('testTypeSubCategoryId')?.value === null) &&
        (formGroup.get('additionalTestId')?.value === null) &&
        (formGroup.get('tatId')?.value === null) &&
        (formGroup.get('chain')?.value === null) &&
        (formGroup.get('authenticationCode')?.value === null || formGroup.get('authenticationCode')?.value === "") &&
        (formGroup.get('agencyCaseNo')?.value === null || formGroup.get('agencyCaseNo')?.value === "") &&
        (formGroup.get('docketNo')?.value === null || formGroup.get('docketNo')?.value === "") &&

        (formGroup.get('caseCreatedStartDate')?.value === null) &&
        (formGroup.get('caseCreatedBy')?.value === null) &&
        (formGroup.get('sampleReceivedStartDate')?.value === null) &&
        (formGroup.get('dueStartDate')?.value === null) &&
        (formGroup.get('accessionedStartDate')?.value === null) &&
        (formGroup.get('accessionedBy')?.value === null) &&
        (formGroup.get('qcStartDate')?.value === null) &&
        (formGroup.get('qcBy')?.value === null) &&
        (formGroup.get('auditedStartDate')?.value === null) &&
        (formGroup.get('auditedBy')?.value === null) &&
        (formGroup.get('testedOnStartDate')?.value === null) &&
        (formGroup.get('analysedOnStartDate')?.value === null) &&
        (formGroup.get('directorSoStartDate')?.value === null) &&
        (formGroup.get('closedStartDate')?.value === null) &&
        (formGroup.get('closedBy')?.value === null) &&

        (formGroup.get('language')?.value === null) &&
        (formGroup.get('emboss')?.value === null) &&
        (formGroup.get('affidavit')?.value === null) &&

        (formGroup.get('billingType')?.value === null) &&
        (formGroup.get('courtOrder')?.value === null) &&

        (formGroup.get('allSampleReceivedStartDate')?.value === null) &&
        (formGroup.get('sampleType')?.value === null) &&
        (formGroup.get('deceased')?.value === null) &&
        (formGroup.get('gender')?.value === null) &&
        (formGroup.get('raceId')?.value === null) &&
        (formGroup.get('collectionStartDate')?.value === null) &&
        (formGroup.get('collectionAgentId')?.value === null) &&
        (formGroup.get('collectionSiteId')?.value === null) &&

        (formGroup.get('sampleId')?.value === null) &&
        (formGroup.get('name')?.value === null) &&
        (formGroup.get('aka')?.value === null) &&
        (formGroup.get('ssn')?.value === null) &&
        (formGroup.get('extPartyIdentifier')?.value === null)

      ) {
        return { allFieldsNullAdv: true }
      }
      return null;
    }
  }



  ngOnInit(): void {

    //Focus on pageload
    setTimeout(() => {
      this.CaseNoQs?.nativeElement?.focus();
    });


    // Check if quick search data is available in local storage.
    if (localStorage.getItem("quickSearchData") != null) {
      this.tabView = 1;
      this.quickSearchDataFromLS = JSON.parse(localStorage.getItem('quickSearchData')!);
      this.quickSearchDataToParent.emit(this.quickSearchDataFromLS);

      this.quickSearchForm.controls.caseNo.setValue(this.quickSearchDataFromLS.caseNo);
      this.quickSearchForm.controls.referenceNo.setValue(this.quickSearchDataFromLS.referenceNo);
      this.quickSearchForm.controls.testedParty.setValue(this.quickSearchDataFromLS.testedParty);
      this.quickSearchForm.controls.dob.setValue(this.quickSearchDataFromLS.dob);
    }

    if (localStorage.getItem("advancedSearchData") != null) {
      this.tabView = 2;
      let advancedSearchDataFromLS = JSON.parse(localStorage.getItem('advancedSearchData')!);
      // console.log(advancedSearchDataFromLS)
      this.advS2 = advancedSearchDataFromLS;

      this.advSearchForm.patchValue(advancedSearchDataFromLS);
      if (advancedSearchDataFromLS?.stateId?.stateId) {
        this.getAgencyList(advancedSearchDataFromLS.stateId.stateId);
      }
      if (advancedSearchDataFromLS?.testTypeId?.testTypeId) {
        this.getSubCategory(advancedSearchDataFromLS.testTypeId.testTypeId);
      }
      if (advancedSearchDataFromLS?.language) {
        this.setItems = advancedSearchDataFromLS?.language.map((item: any) => {
          return item.langId;
        })
      }
      this.advcancedSearch();
      // FORM BINDING
    }


    /*
    1. Channel
    2. Test type
    3. Additional Testing
    4. Languages
    5. StateList
    */
    this.getInitialData();
    this.tatCreate();
  }

  getInitialData(): any {

    let apiArray = [
      this.caseService.getChannelListingRegular(),
      this.caseService.gettestTypeListing(10, 1),
      this.caseService.getadditionalTestListing(),
      this.caseService.getLanguages(this.pagination),
      this.caseService.getStateListing("", 1, 200),
      this.caseService.getUserData(),
      this.caseService.getSampleTypes(),
      this.caseService.getTestPartyRace(this.pagination),
      this.caseService.getCollectorSite(this.pagination),
      this.caseService.collectorAgents(this.pagination)
    ];

    this.caseService.forkJoinData(apiArray).subscribe((res: any) => {
      this.channelArrayList = res[0].data.channels;
      this.testTypeData = res[1].data.testTypes;
      this.additionalTestingArray = res[2].data.additionalTests;
      this.languageArrayList = res[3].data.languages;
      this.stateArrayList = res[4].data.states;
      this.userArrayList = res[5].data.users;
      this.sampleType = res[6].data.sampleTypes;
      this.raceTypeArray = res[7].data.testPartyRaces;
      this.collectionSiteArrayList = res[8].data.collectionSites;
      this.collectionAgentArrayList = res[9].data.collectionAgents;
      this.createFullName();

    })

  }

  /*
   * @Desc   : Get Channel list datafor dropdown.
   * @Author : Arjun S
   * @Param  : 
   */

  getChannelList() {
    this.loaderService.isLoaderEnable(true);
    this.caseService.getChannelListing().subscribe(
      (response) => {
        if (response.success) {
          this.channelArrayList = response.data.channels.filter((cType: any) => cType.channelType === "regular");
        } else {
          this.channelArrayList = [];
        }
        this.loaderService.isLoaderEnable(false);
      },
      (err: HttpErrorResponse) => {
        this.loaderService.isLoaderEnable(false);
        this.alertandtoaster.alert.toast({
          title: 'Error',
          type: 'error',
          message: err?.error?.message,
        });
      }
    );
  }

  /*
   * @Desc   : Get the list of states .
   * @Author : Arjun S
   * @Param  : Nill
   */

  getStateList(searchString: string) {
    this.loaderService.isLoaderEnable(true);
    this.caseService.getStateListing(searchString, 1, 200).subscribe(
      (response) => {
        if (response.success) {
          this.stateArrayList = response.data.states;
        }
        else {
          this.stateArrayList = [];
        }
        this.loaderService.isLoaderEnable(false);
      },
      (err: HttpErrorResponse) => {
        this.loaderService.isLoaderEnable(false);
        this.utility.apiHttpErrorHandler(err);

      }
    );
  }

  /*
   * @Desc   :  Get the list of Agencies .
   * @Author : Arjun S
   * @Param  : State id
   */
  getAgencyList(stateId: number, searchString?: any) {
    searchString = searchString ? searchString : "";
    this.loaderService.isLoaderEnable(true);
    this.caseService.getAgencyListing(stateId, searchString, 1, 200).subscribe(
      (response) => {
        if (response.success) {
          this.agencyArrayList = response.data.agencies;
        }
        else {
          this.agencyArrayList = [];
        }
        this.loaderService.isLoaderEnable(false);
      },
      (err: HttpErrorResponse) => {
        this.loaderService.isLoaderEnable(false);
        this.utility.apiHttpErrorHandler(err);

      }
    );
  }


  /*
   * @Desc   : Get the list of test types .
   * @Author : Arjun S
   * @Param  : Nill
   */
  getTestTypes() {
    this.loaderService.isLoaderEnable(true);
    this.caseService.gettestTypeListing(this.testTypePageNo, this.testTypePageSize).subscribe(
      (response) => {
        if (response.success) {
          this.testTypeData = response.data.states;
        }
        else {
          this.testTypeData = [];
        }
        this.loaderService.isLoaderEnable(false);
      },
      (err: HttpErrorResponse) => {
        this.loaderService.isLoaderEnable(false);
        this.utility.apiHttpErrorHandler(err);

      }
    );
  }


  /*
   * @Desc   : Get the list of sub categories .
   * @Author : Arjun S
   * @Param  : Nill
   */
  getSubCategory(testTypeId: number) {
    this.loaderService.isLoaderEnable(true);
    this.caseService.getSubCategoryData(testTypeId, 1, 100).subscribe(
      (response) => {
        if (response.success) {
          this.subCategoryArrayList = response.data.testSubCategories;
        }
        else {
          this.subCategoryArrayList = [];
        }
        this.loaderService.isLoaderEnable(false);
      },
      (err: HttpErrorResponse) => {
        this.loaderService.isLoaderEnable(false);
        this.utility.apiHttpErrorHandler(err);
      }
    );
  }

  /*
   * @Desc   : Get the list of languages .
   * @Author : Arjun S
   * @Param  : Nill
   */

  selectedLanguage(event: any) {
    let temp: any[] = [];
    let selectedLanguages = event;
    this.languageArrayList.forEach((item: any) => {
      selectedLanguages.forEach((item2: string) => {
        if (item.langName === item2) {
          let obj = {
            "langId": item.langId,
            "langName": item.langName,

          }
          temp.push(obj)
        }
      });
    });
    this.advSearchForm.controls.language?.setValue(temp);
  }

  /*
   * @Desc   : Get tat Ids .
   * @Author : Arjun S
   * @Param  : Nill
   */


  tatMastersList(agencyId: number) {
    this.loaderService.isLoaderEnable(true);
    this.caseService.getTatListing(250).subscribe(
      (response) => {
        if (response.success) {
          this.tatTypeArrayList = response.data.tatList;
          this.tatTypeArrayList.forEach((item: any) => {
            item.tatTimeDisplay = `${item.tatTime}W Days`;
            this.tatTime.push(item)
          })
        }
        else {
          this.tatTypeArrayList = [];
        }
        this.loaderService.isLoaderEnable(false);
      },
      (err: HttpErrorResponse) => {
        this.loaderService.isLoaderEnable(false);
        this.utility.apiHttpErrorHandler(err);

      }
    );
  }

  /*
    GET collection agents
    Abhiram (Reused)
  */
  collectionAgentwithSearchApi(value : string) {
    let req =  {
      'pageNo': 1,
      'name': value
    }
    this.caseService.collectorAgents(req).subscribe((res) => {
      this.collectionAgentArrayList = res.data.collectionAgents;
      this.createFullName();
    });
  }


  getCollectionsite(value: any){
    let req =  {
      'pageNo': 1,
      'stName': value
    }
    this.caseService.getCollectorSite(req).subscribe(res => {
      this.collectionSiteArrayList = res.data.collectionSites;
    });
  }




  /*
   * @Desc   : RETURN DATA FROM 
    1. Channel
    2. State
    3. Agencies
    4. Test type
    5. Additional testing
    6. Sub category
    7. TAT
    8. Created by
    9. Accessioned by
    10. Qc by
    11. Audited by
    12. Closed by
  .
   * @Author : Arjun S
   * @Param  : Nill
   */



  selectedChannel(event: any) {
    this.advSearchForm.controls.channelId.setValue(event);
    if (event.channelId !== 1) {
      this.advSearchForm.controls.stateId.setValue(null);
      this.advSearchForm.controls.agencyId.setValue(null);
      this.advSearchForm.controls.chain.setValue(null);



    } else {

      this.advSearchForm.controls.chain.patchValue('1');

    }
  }

  selectedState(event: any) {
    this.advSearchForm.controls.stateId.setValue(event);
    // console.log("AAR", this.agencyArrayList)
    this.agencyArrayList = [];
    this.getAgencyList(event.stateId);

  }

  selectedAgencies(event: any) {
    this.advSearchForm.controls.agencyId.setValue(event);
  }

  selectedTat(event: any) {
    this.advSearchForm.controls.tatId.setValue(event);
  }

  selectedType(event: any) {
    this.advSearchForm.controls.chain.setValue(event.id);
  }

  selectedRace(event: any) {
    this.advSearchForm.controls.raceId.setValue(event);
  }

  selectedTestType(event: any) {
    this.advSearchForm.controls.testTypeId.setValue(event);
    this.advSearchForm.controls.testTypeSubCategoryId.setValue(null);
    this.subCategoryArrayList = [];
    this.getSubCategory(event.testTypeId);
  }

  selectedAddtionalTesting(event: any) {
    this.advSearchForm.controls.additionalTestId.setValue(event);
  }

  selectedSubcategory(event: any) {
    this.advSearchForm.controls.testTypeSubCategoryId.setValue(event);

  }

  selectedSampleType(event: any) {
    this.advSearchForm.controls.sampleType.setValue(event);
  }

  createdBy(event: any) {
    this.advSearchForm.controls.caseCreatedBy.setValue(event);
  }

  acessionedBy(event: any) {
    this.advSearchForm.controls.accessionedBy.setValue(event);
  }

  qcBy(event: any) {
    this.advSearchForm.controls.qcBy.setValue(event);
  }

  auditedBy(event: any) {
    this.advSearchForm.controls.auditedBy.setValue(event);
  }

  closedBy(event: any) {
    this.advSearchForm.controls.closedBy.setValue(event);
  }

  selectCollectionAgentId(event: any) {
    this.advSearchForm.controls.collectionAgentId.setValue(event);
  }

  selectCollectionSiteId(event: any) {
    this.advSearchForm.controls.collectionSiteId.setValue(event);
  }

  selectChangeLanguage(event: any) {
    if (event && event.length) {
      this.setItems = event.map(function (item: any) {
        return item.langId;
      })
      this.advSearchForm.controls.language.setValue(event);
    }
    else {
      this.advSearchForm.controls.language.setValue(null);
    }
  }



  /*
   * @Desc   : Change tab View from quick search to advanced search.
   * @Author : Arjun S
   * @Param  : tabView- true=quick, false= advanced
   */
  // changeTabView(tabView: number) {
  //   this.tabView = tabView
  // }
  // changeTabView(tabView: boolean) {
  //   this.tabView = tabView ? true: false;
  // }


  createFullName() {
    this.collectionAgentArrayList.forEach((element: any) => {
      let fullName = element.agentName + ' ' + element.agentLastName
      element.agentName = fullName;
    });
  }



  /*
   * @Desc   : Clear data from quick search fields.
   * @Author : Arjun S
   * @Param  : Nill
   */
  clearQuickSearchData() {
    this.quickSearchForm.controls.caseNo.setValue(null);
    this.quickSearchForm.controls.referenceNo.setValue(null);
    this.quickSearchForm.controls.testedParty.setValue(null);
    this.quickSearchForm.controls.dob.setValue(null);
    localStorage.removeItem('quickSearchData');
    this.clearData.emit(true);
  }

  /*
   * @Desc   : Quick search data submission .
   * @Author : Arjun S
   * @Param  : Nill
   */
  quickSearch() {
    this.advSearchForm.reset();
    localStorage.setItem('current_page', JSON.stringify(1));
    // Uncomment this to close filter after search.
    // this.collapseFilter = false;
    this.quickSearchData = {
      caseNo: this.quickSearchForm.value.caseNo,
      referenceNo: this.quickSearchForm.value.referenceNo,
      testedParty: this.quickSearchForm.value.testedParty,
      dob:
        this.quickSearchForm.value.dob != null ?
          moment(this.quickSearchForm.value.dob).format('YYYY-MM-DD')
          : undefined
    }
    // Removes Adv Search data when quick search submit is pressed
    localStorage.removeItem('advancedSearchData');
    this.quickSearchDataToParent.emit(this.quickSearchData);
  }

  /*
   * @Desc   : Advanced search data clear .
   * @Author : Arjun S
   * @Param  : Nill
   */

  clearAdvancedSearch() {
    this.setItems = [];
    this.subCategoryArrayList = [];
    localStorage.removeItem('advancedSearchData');
    this.advSearchForm.reset();
    this.advS2 = [];
    this.clearData.emit(true);
  }

  /*
   * @Desc   : Edit advanced search data.
   * @Author : Arjun S
   * @Param  : Nill
   */
  edit() {
    this.tabView = 2;
    this.advSearchForm.patchValue = this.advS2;
  }

  /*
  * @Desc   : Remove bubble data.
  * @Author : Arjun S
  * @Param  : Nill
  */
  removeSD(param: string) {

    if (param === 'channelId' && this.advS2.channelId.channelId === 1) {
      this.advSearchForm.controls.stateId.setValue(null);
      this.advS2.stateId = null;
      this.advSearchForm.controls.agencyId.setValue(null);
      this.advS2.agencyId = null;
      this.advSearchForm.controls.chain.patchValue(null);
      this.advS2.chain = null;
    }
    if (param === 'testTypeId') {
      this.advSearchForm.controls.testTypeSubCategoryId.patchValue(null);
      this.advS2.testTypeSubCategoryId = null;
      this.subCategoryArrayList = []
    }
    if (param === 'stateId') {
      this.advSearchForm.controls.agencyId.setValue(null);
      this.advS2.agencyId = null;
      this.advSearchForm.controls.tatId.setValue(null);
      this.advS2.tatId = null;
    }
    if (param === 'agencyId') {
      this.advSearchForm.controls.tatId.setValue(null);
      this.advS2.tatId = null;
    }

    if (param === 'language') {
      this.setItems = [];
    }

    this.advSearchForm.controls[`${param}`].setValue(null);
    this.advS2[`${param}`] = null;
    localStorage.setItem('advancedSearchData', JSON.stringify(this.advS2));


    let result = Object.values(this.advS2).every(item => item === null);
    if (result) {
      this.tabView = 2;
      this.clearAdvancedSearch();
      return
    }

    this.advcancedSearch();
  }

  /*
  * @Desc   : Advanced search data submission .
  * @Author : Arjun S
  * @Param  : Nill
  */
  advcancedSearch() {
    this.quickSearchForm.reset();
    this.tabView = 3;
    localStorage.setItem('current_page', JSON.stringify(1))
    localStorage.removeItem('quickSearchData');

    this.advS2 = this.advSearchForm.value;
    // console.log(this.advS2)
    localStorage.setItem('advancedSearchData', JSON.stringify(this.advS2));

    let AdvSearchObject = this.getObject();
    this.AdvancedSearchDataToParent.emit(AdvSearchObject);


  }

  /*
  * @Desc   : Object return for  AS data .
  * @Author : Arjun S
  * @Param  : Nill
  */

  getObject() {
    return Object.assign(this.getCaseDeatils(), this.getDates(), this.getrequirementsAndPaymentDetails(), this.getTestedPartyDetails());
  }


  getCaseDeatils() {
    return {
      channelId: this.advS2.channelId?.channelId ? this.advS2.channelId.channelId : null,
      stateId: this.advS2.stateId?.stateId ? this.advS2.stateId.stateId : null,
      agencyId: this.advS2.agencyId?.agencyId ? this.advS2.agencyId.agencyId : null,
      authenticationCode: this.advS2?.authenticationCode ? this.advS2.authenticationCode : null,
      agencyCaseNo: this.advS2.agencyCaseNo ? this.advS2.agencyCaseNo : null,
      docketNo: this.advS2?.docketNo,
      testTypeId: this.advS2.testTypeId?.testTypeId ? this.advS2.testTypeId.testTypeId : null,
      testTypeSubCategoryId: this.advS2.testTypeSubCategoryId?.subCategoryId ? this.advS2.testTypeSubCategoryId.subCategoryId : null,
      additionalTestId: this.advS2.additionalTestId?.id ? this.advS2.additionalTestId.id : null,
      // tatId: this.advS2.tatId?.id ? this.advS2.tatId.id : null,
      chain: this.advS2?.chain ? this.advS2?.chain : null,
    }
  }

  getDates() {
    return {
      caseCreatedEndDate: this.advS2.caseCreatedEndDate != null ? moment(this.advS2.caseCreatedEndDate).format('YYYY-MM-DD') : null,
      caseCreatedStartDate: this.advS2.caseCreatedStartDate != null ? moment(this.advS2.caseCreatedStartDate).format('YYYY-MM-DD') : null,
      caseCreatedBy: this.advS2.userId ? this.advS2.userId : null,
      sampleReceivedEndDate: this.advS2.sampleReceivedEndDate != null ? moment(this.advS2.sampleReceivedEndDate).format('YYYY-MM-DD') : null,
      sampleReceivedStartDate: this.advS2.sampleReceivedEndDate != null ? moment(this.advS2.sampleReceivedEndDate).format('YYYY-MM-DD') : null,
      dueEndDate: this.advS2.dueEndDate != null ? moment(this.advS2.dueEndDate).format('YYYY-MM-DD') : null,
      dueStartDate: this.advS2.dueStartDate != null ? moment(this.advS2.dueStartDate).format('YYYY-MM-DD') : null,
      accessionedBy: this.advS2.accessionedBy?.userId ? this.advS2.accessionedBy?.userId : null,
      accessionedEndDate: this.advS2.accessionedEndDate != null ? moment(this.advS2.accessionedEndDate).format('YYYY-MM-DD') : null,
      accessionedStartDate: this.advS2.accessionedStartDate != null ? moment(this.advS2.accessionedStartDate).format('YYYY-MM-DD') : null,
      // qcBy: this.advS2.qcBy?.userId ? this.advS2.qcBy?.userId : null,
      // qcEndDate: this.advS2.qcEndDate != null ? moment(this.advS2.qcEndDate).format('YYYY-MM-DD') : null,
      // qcStartDate: this.advS2.qcStartDate != null ? moment(this.advS2.qcStartDate).format('YYYY-MM-DD') : null, 
      // auditedBy: this.advS2?.auditedBy?.userId ? this.advS2?.auditedBy?.userId : null,
      auditedEndDate: this.advS2.auditedEndDate != null ? moment(this.advS2.auditedEndDate).format('YYYY-MM-DD') : null,
      auditedStartDate: this.advS2.auditedStartDate != null ? moment(this.advS2.auditedStartDate).format('YYYY-MM-DD') : null,
      // testedOnStartDate = null,
      // testedOnEndDate = null,
      // AnalysedOnStartDate = null,
      // AnalysedOnEndDate = null,

    }
  }



  getrequirementsAndPaymentDetails() {
    return {

      directorSoEndDate: this.advS2.directorSoEndDate != null ? moment(this.advS2.directorSoEndDate).format('YYYY-MM-DD') : null,
      directorSoStartDate: this.advS2.directorSoEndDate != null ? moment(this.advS2.directorSoEndDate).format('YYYY-MM-DD') : null,
      closedEndDate: this.advS2.closedEndDate != null ? moment(this.advS2.closedEndDate).format('YYYY-MM-DD') : null,
      closedStartDate: this.advS2.closedStartDate != null ? moment(this.advS2.closedStartDate).format('YYYY-MM-DD') : null,
      closedBy: this.advS2?.closedBy?.userId ? this.advS2?.closedBy?.userId : null,


      languages: this.setItems,
      emboss: this.advS2?.emboss,
      affidavit: this.advS2?.affidavit,

      billingType: this.billingTypeValue(),
      courtOrder: this.advS2?.courtOrder,

    }
  }

  billingTypeValue() {
    if (this.advS2?.billingType != null) {
      if (this.advS2?.billingType) {
        return 1;
      } else {
        return null;
      }
    }
    return null;
  }


  getTestedPartyDetails() {
    return {

      sampleId: this.advS2?.sampleId != null ? this.advS2?.sampleId : null,
      allSampleReceivedStartDate: this.advS2.allSampleReceivedStartDate !== null ? moment(this.advS2.allSampleReceivedStartDate).format('YYYY-MM-DD') : null,
      allSampleReceivedEndDate: this.advS2.allSampleReceivedEndDate !== null ? moment(this.advS2.allSampleReceivedEndDate).format('YYYY-MM-DD') : null,
      sampleTypeId: this.advS2?.sampleType?.id != null ? this.advS2?.sampleType.id : null,
      name: this.advS2?.name,
      aka: this.advS2?.aka,
      deceased: this.advS2?.deceased,
      gender: this.advS2?.gender,
      ssn: this.advS2?.ssn,
      raceId: this.advS2?.raceId?.raceId != null ? this.advS2?.raceId?.raceId : null,
      collectionStartDate: this.advS2.collectionStartDate !== null ? moment(this.advS2.collectionStartDate).format('YYYY-MM-DD') : null,
      collectionEndDate: this.advS2.collectionEndDate !== null ? moment(this.advS2.collectionEndDate).format('YYYY-MM-DD') : null,

      collectionAgentId: this.advS2?.collectionAgentId?.id ? this.advS2?.collectionAgentId?.id : null,
      collectionSiteId: this.advS2?.collectionSiteId?.id ? this.advS2?.collectionSiteId?.id : null,
      extPartyIdentifier: this.advS2?.extPartyIdentifier,


    }
  }

  /*
  * @Desc   : Scrollling this section into view.
  * @Author : Arjun S
  * @Param  : Nill
  */
  scrollIntoView() {
    setTimeout(() => {
      try {
        this.tabWindow.nativeElement.scrollTop = this.tabWindow.nativeElement.scrollHeight;
      } catch (err) { }

    });
  }

  /*
  * @Desc   : tat data create.
  * @Author : Abhiram
  * @Param  : Nill
  */

  tatCreate(): void {
    this.tatTypeArrayList = [];
    for (let i = 0; i <= 45; i++) {
      const obj = {
        'id': i,
        'tatDisplay': i + ' W Day(s)'
      }
      this.tatTypeArrayList.push(obj);
    }
  }

  testFuction(value: any) {
    console.log(value);
  }
}
