import { Component, EventEmitter, Input, Output, ViewChild, ElementRef } from '@angular/core';
import {
  FormGroup,
  FormControl,
  Validators,
  ValidatorFn,
  ValidationErrors,
  AbstractControl,
} from '@angular/forms';
import { CustomValidation } from 'src/app/shared/Utilities/custom-validator';
import {
  PaginationDetails,
  CollectionAgent,
  CollectionSite,
} from 'src/app/core/Models/Interfaces/case';
import { CaseService } from '../../services/case.service';
import { AlertandtoasterService } from 'src/app/shared/Services/alertandtoaster.service';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-collector-name-selector',
  templateUrl: './collector-name-selector.component.html',
  styleUrls: ['./collector-name-selector.component.css'],
})
export class CollectorNameSelectorComponent {
  isAddView: boolean = false;
  @Input('inputData') testPartyDetails: any;
  @Output() selectedObject = new EventEmitter<CollectionSite | null>();
  @Output() closeEvent: EventEmitter<boolean> = new EventEmitter<boolean>();
  form: FormGroup;
  collectionDetails: CollectionAgent[] = [];
  loadingInProgress: boolean = false;
  pagination: PaginationDetails = {
    pageNo: 1,
    pageSize: 10,
    totalPages: 1,
  };
  filterObj!: {};
  @ViewChild('focus') focus!: ElementRef;

  public get controls() {
    return this.form.controls;
  }
  constructor(
    private caseService: CaseService,
    private alertandtoaster: AlertandtoasterService
  ) {
    this.form = new FormGroup({
      name: new FormControl(
        null,
        Validators.compose([
          CustomValidation.noSpaceOnly,
          Validators.maxLength(20),
          Validators.minLength(1),
        ])
      ),
    }, Validators.compose([this.confirmACCNOValidation()]));
  }

  ngAfterViewInit(): void {
    this.focus?.nativeElement.focus();
  }

  private confirmACCNOValidation(): ValidatorFn {
    return (formGroup: AbstractControl): ValidationErrors | null => {
      let name = formGroup.get('name')?.value;
      if (name) {
        return null;
      }
      return { required: true };
    };
  }

  addOpenModal(): void {
    this.isAddView = true;
  }

  /*
   * @desc: apply a filter.
   * @author: submit
   */
  submit() {
    if (this.form.invalid) {
      return;
    } else {
      this.collectionDetails = [];
      this.pagination = {
        pageNo: 1,
        pageSize: 10,
        totalPages: 1,
      };
      this.getCollectionDetails(this.pagination);
    }
  }
  /*
   * @desc: to get collection details
   * @author: Nilena Alexander
   */
  getCollectionDetails(obj: {}) {
    this.loadingInProgress = true;
    this.filterObj = {
      ...this.form.value,
      pageNo: this.pagination.pageNo,
      pageSize: this.pagination.pageSize ? this.pagination.pageSize : null,
    };
    this.caseService.collectorAgents(this.filterObj).subscribe(
      (response) => {
        if (response.success) {
          this.collectionDetails.push(...response.data.collectionAgents);
          this.pagination.totalPages = response.data.totalPages;
          this.loadingInProgress = false;
        } else {
          this.form.reset();
          this.collectionDetails = [];
          this.loadingInProgress = false;
          this.alertandtoaster.alert.toast({
            title: 'Error',
            type: 'error',
            message: response?.message,
          });
        }
      },
      (error: HttpErrorResponse) => {
        this.collectionDetails = [];
        this.form.reset();
        this.loadingInProgress = false;
        this.alertandtoaster.alert.toast({
          title: 'Error',
          type: 'error',
          message: error?.error?.message,
        });
      }
    );
  }

  /*
   * @desc: Cancel the applyed filter.
   * @author: Abhiram M Sajeev
   */
  clearFilter() {
    this.collectionDetails = [];
    this.pagination = {
      pageNo: 1,
      pageSize: 10,
      totalPages: 1,
    };
    this.form.reset();

  }

  /*
   * @desc: to detct scrolland call api
   * @author: Abhiram M Sajeev
   */
  public onScrollEnd() {
    if (
      this.loadingInProgress ||
      !this.collectionDetails.length ||
      this.pagination.pageNo >= this.pagination?.totalPages
    )
      return;
    this.pagination.pageNo += 1;
    this.getCollectionDetails(this.pagination);
  }

  close() {
    this.closeEvent.emit();
  }
  selectedAgenent(value: any) {
    this.selectedObject.emit(value);
    this.close();
  }
}
