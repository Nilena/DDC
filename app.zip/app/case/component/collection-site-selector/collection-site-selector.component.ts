
import { Component, EventEmitter, Input, Output, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators, ValidatorFn,
  AbstractControl,
  ValidationErrors } from '@angular/forms';
import { CaseService } from '../../services/case.service';
import {
  CollectionSite,
  PaginationDetails,
} from 'src/app/core/Models/Interfaces/case';
import { CustomValidation } from 'src/app/shared/Utilities/custom-validator';
import { AlertandtoasterService } from 'src/app/shared/Services/alertandtoaster.service';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'app-collection-site-selector',
  templateUrl: './collection-site-selector.component.html',
  styleUrls: [
    '../../../../assets/style/css/case.css',
    '../../../../assets/style/css/accordion.css',
  ],
})
export class CollectionSiteSelectorComponent  {
  @Output() selectedObject = new EventEmitter<CollectionSite | null>();
  @Output() closeEvent: EventEmitter<boolean> = new EventEmitter<boolean>();
  @Input('inputData') testPartyDetails: any;
  agencyName = new FormControl('');
  zipcode = new FormControl('');
  addCollectionSite!: FormGroup;
  isAddNew: boolean = false;
  loadingInProgress: boolean = false;
  form: FormGroup;
  pagination: PaginationDetails = {
    pageNo: 1,
    pageSize: 10,
    totalPages: 1,
  };



  public get controls() { return this.form.controls }
  @ViewChild('focus') focus!: ElementRef;


  filterObj!: {};
  collectionDetails: CollectionSite[] = [];
  constructor(
    private caseService: CaseService,
    private fb: FormBuilder,
    private alertandtoaster: AlertandtoasterService
  ) {
    this.form = new FormGroup({
      stName : new FormControl(
        null,
        Validators.compose([
          CustomValidation.noSpaceOnly,
          Validators.maxLength(20), Validators.minLength(1)
        ])
      ),
      zip: new FormControl(
        null,
        Validators.compose([
          CustomValidation.onlyNumber,
          Validators.maxLength(10), Validators.minLength(1)
        ])
      ), 
    }, Validators.compose([this.confirmACCNOValidation()]));
    

  }

  ngAfterViewInit(){
      this.focus?.nativeElement.focus();
  }
  


  private confirmACCNOValidation(): ValidatorFn {
    return (formGroup: AbstractControl): ValidationErrors | null => {
      let zip = formGroup.get('zip')?.value;
      let stName  = formGroup.get('stName')?.value;
      if (zip || stName  ) {
        return null
      }
      else if ( !zip ){
      return  { required: true };
      }
      else if (! stName ){
        return  {required: true };
        }else{
          return  { invalid: true };
        }      
    }
  }
  /*
   * @desc: to get details of searched items
   * @author: Nilena Alexander
   */
  getCollectionSiteDetails(obj: {}) {
    this.loadingInProgress = true;
    this.filterObj = {
      ...this.form.value,
      pageNo: this.pagination.pageNo,
      pageSize: this.pagination.pageSize ? this.pagination.pageSize : null,
    };
    this.caseService.getCollectorSite(this.filterObj).subscribe(
      (response) => {
        if (response.success) {
          this.collectionDetails.push(...response.data.collectionSites);
          this.pagination.totalPages = response.data.totalPages;
          this.loadingInProgress = false;
        } else {
          this.form.reset();
          this.collectionDetails = [];
          this.loadingInProgress = false;
          this.alertandtoaster.alert.toast({
            title: 'Error',
            type: 'error',
            message: response?.message,
          });
        }
      },
      (error: HttpErrorResponse) => {
        this.collectionDetails = [];
        this.form.reset();
        this.loadingInProgress = false;
        this.alertandtoaster.alert.toast({
          title: 'Error',
          type: 'error',
          message:error?.error?.message,
        });
      }
    );
  }
  /*
   * @desc: apply a filter.
   * @author: Abhiram M Sajeev
   */
  submit() {
     if (this.form.invalid) {
      return;
    } else {
      this.collectionDetails = [];
      this.pagination = {
        pageNo: 1,
        pageSize: 10,
        totalPages: 1,
      };
      this.getCollectionSiteDetails(this.pagination);
    }
  }

  public onScrollEnd() {
    if(this.loadingInProgress ||
      !this.collectionDetails.length ||
      this.pagination.pageNo >= this.pagination?.totalPages)
      return;
    this.pagination.pageNo += 1;
    this.getCollectionSiteDetails(this.pagination);
  }

  /*
   * @desc: Cancel the applyed filter.
   * @author: Abhiram M Sajeev
   */
  clearFilter() {
    this.collectionDetails = [];
    this.pagination = {
      pageNo: 1,
      pageSize: 10,
      totalPages: 1,
    };
    this.form.reset();
  }

  /*
   * @desc: Open add form
   * @author: Abhiram M Sajeev
   */
  openAddNewForm() {
    this.isAddNew = true;
    this.createAddForm();
  }

  /*
   * @desc:Create collection site
   * @author: Abhiram M Sajeev
   */
  createAddForm() {
    this.addCollectionSite = this.fb.group({
      agencyName: ['', Validators.required],
      comments: ['', Validators.required],
      state: ['', Validators.required],
      zip: ['', Validators.required],
      tier: ['', Validators.required],
    });
  }


  /*
   * @desc: Close Modal
   * @author: Abhiram M Sajeev
   */
  closeModal(): void {
    this.closeEvent.emit(true);
  }
  /*
   * @desc: to send selected object
   * @author: Nilena Alexander
   */
  selectedCollectionSite(item: CollectionSite) {
    this.selectedObject.emit(item);
    this.closeModal();
  }
}
