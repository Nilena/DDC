import { Component, OnInit } from '@angular/core';
import {
  CaseDetails,
  SampleDetails,
} from 'src/app/core/Models/Interfaces/case';
import { CaseService } from '../../services/case.service';
import { LoaderService } from 'src/app/core/Services/loader.service';
import { AlertandtoasterService } from 'src/app/shared/Services/alertandtoaster.service';
import { ActivatedRoute } from '@angular/router';
import { HttpErrorResponse } from '@angular/common/http';
import { UtilityService } from 'src/app/shared/Services/utility.service';

@Component({
  selector: 'app-case-details',
  templateUrl: './case-details.component.html',
  styleUrls: [
    '../../../../assets/style/css/case.css',
    '../../../../assets/style/css/accordion.css',
  ],
})
export class CaseDetailsComponent implements OnInit {
  caseDetailCollapse: boolean = true;
  sampleDetailCollapse: boolean = true;
  CaseDetails!: CaseDetails;
  sampleDetails: SampleDetails[] = [];
  caseId!: number;
  constructor(
    private caseService: CaseService,
    private loader: LoaderService,
    private alertandtoaster: AlertandtoasterService,
    private route: ActivatedRoute,
    private utility: UtilityService
  ) {
    this.caseId = this.route.snapshot.params['id'];
  }

  ngOnInit(): void {
    this.loader.isLoaderEnable(true);
    this.getCaseDetails(Number(this.caseId));
    if (localStorage.getItem('docId')) {
      localStorage.removeItem('docId');
    }
  }

    /**
     * @author: Nilena Alexander
     * @desc : to get case details of particular case
     * @param id :number
     */
    getCaseDetails(id: number) {
      this.caseService.getCaseDetails(id).subscribe((response) => {
        if (response.success) {
          this.CaseDetails = response.data.caseDetails;
          this.sampleDetails = response.data.caseDetails.samples;
          this.loader.isLoaderEnable(false);
        } else {
          this.alertandtoaster.alert.toast({
            title: 'Error',
            type: 'error',
            message: response?.message,
          });
          this.loader.isLoaderEnable(false);
        }
      }, (error: HttpErrorResponse) => {
        this.CaseDetails = {};
        this.utility.apiHttpErrorHandler(error);
        this.loader.isLoaderEnable(false);
      });
    }

    back() {
      window.history.back();
    }

    ngOnDestroy(){
      localStorage.removeItem('docId');
    }
  }
