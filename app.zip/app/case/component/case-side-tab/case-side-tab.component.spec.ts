import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CaseSideTabComponent } from './case-side-tab.component';

describe('CaseSideTabComponent', () => {
  let component: CaseSideTabComponent;
  let fixture: ComponentFixture<CaseSideTabComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CaseSideTabComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CaseSideTabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
