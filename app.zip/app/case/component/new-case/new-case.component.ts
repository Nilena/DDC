import { HttpErrorResponse } from '@angular/common/http';
import { Component, ElementRef, OnInit, Renderer2, ViewChild } from '@angular/core';
import { FormGroup, Validators, FormBuilder, FormArray } from '@angular/forms';
import { AdditionalTest, Agencies, Channels, States, TestType, Languages, TatType, TestSubCategories, UserDetails, ScanNewForm, PaginationDetails, TestedPartyRoles, SampleType, TestPartyRaces } from 'src/app/core/Models/Interfaces/case';
import * as moment from 'moment';
import { LoaderService } from 'src/app/core/Services/loader.service';
import { AlertandtoasterService } from 'src/app/shared/Services/alertandtoaster.service';
import { CaseService } from '../../services/case.service';
import { Router } from '@angular/router';
import { CONSTANTS } from 'src/app/core/Constants/constants';
import { UtilityService } from 'src/app/shared/Services/utility.service';

@Component({
  selector: 'app-new-case',
  templateUrl: './new-case.component.html',
  styleUrls: ['../../../../assets/style/css/case.css', '../../../../assets/style/css/accordion.css', '../../../../assets/style/css/singleselect.css']

})
export class NewCaseComponent implements OnInit {
  public newCaseForm!: FormGroup;
  testParties: FormArray;
  channelTypeList = CONSTANTS.channelTypeList;
  samplesInfo = CONSTANTS.sampleDetailsLabel;
  casePartyCount = CONSTANTS.testPartys;
  deceasedArr = CONSTANTS.deceased;
  gender = CONSTANTS.gender;
  pagination: PaginationDetails = {
    pageNo: 1,
    pageSize: 100,
    totalPages: 1,
  };
  caseId: number = 0;
  caseDetails: boolean = false;
  sampleDetails: boolean = false;
  tatEnable: boolean = true;
  typeEnable: boolean = true;
  isCollectionSite: boolean = false;
  languageList: Languages[] = [];
  stateList: States[] = [];
  agencyList: Agencies[] = [];
  channelArrayList: Channels[] = [];
  testType: TestType[] = [];
  tatType: TatType[] = [];
  userDetails: UserDetails[] = [];
  AdditioanlTest: AdditionalTest[] = [];
  subCategoryArrayList: TestSubCategories[] = [];
  selectedLanguages: Languages[] = [];
  selectedChannels: Channels[] = [];
  selectedRole: string[] = [];
  scanNewForm !: ScanNewForm;
  StatePerpage: number = 1;
  statePageSize: number = 100;
  AgencyPerpage: number = 10;
  AgencyNum: number = 1;
  testPerpage: number = 10;
  testNum: number = 1;
  typeEvent: any;
  deceasedStatus?: number;
  selectedFormarray!: number;
  stateId !: number;
  onLoadDataList = {} as any;
  today = new Date();
  state: States[] = [];
  tatTime: any[] = [];
  sectetedGender?: string;
  testPartyDetails?: { role: any; name: any; };
  isCollectorAgenetSearch: boolean = false;
  isSubmitted: boolean = false;
  languageSelect: any[] = [];

  @ViewChild('ChannelSelection') ChannelSelection!: ElementRef;

  constructor(private alertandtoaster: AlertandtoasterService,
    private caseService: CaseService, private fb: FormBuilder,
    private router: Router,
    private loaderService: LoaderService, private render: Renderer2,
    private utility: UtilityService) {
    this.getInitialDataList();
    this.testParties = new FormArray([]);
  }

  ngOnInit(): void {
    this.getUserDetails();
    this.createForm();
    setTimeout(() => {
      this.ChannelSelection.nativeElement.focus();
    });
  }

  createForm(): void {
    this.newCaseForm = this.fb.group({
      channelId: [null, [Validators.required]],
      stateId: [null],
      agencyId: [null],
      authenticationCode: [null],
      docketNo: [null],
      agencyCaseNumber: [null],
      testTypeId: [null],
      testTypeSubCategoryId: [null],
      additionalTestId: [null],
      tatId: [null],
      chain: [null],
      isPrivate: [null],
      courtOrder: [null],
      dueDate: [null],
      emboss: [null],
      caseReportLang: [null],
      affidavit: [null],
      testParties: this.testParties
    });
    for (let i = 0; i < 3; i++) {
      this.testParties.push(this.createTestParties());
      (<FormGroup>this.testParties.controls[i]).controls.tpRoleId.patchValue(i + 1);
      if (i === 0) {
        (<FormGroup>this.testParties.controls[i]).controls.gender.patchValue('f');
      }
      if (i === 2) {
        (<FormGroup>this.testParties.controls[i]).controls.gender.patchValue('m');
      }
    }
  }

  /* 
    * @desc: return the formarray control.
    * @author: Abhiram M Sajeev
    */

  createTestParties(): FormGroup {
    return this.fb.group({
      tpRoleId: [null],
      sampleTypeId: [null],
      sampleNo: [null, [Validators.pattern('^[0-9]*$')]],
      sampleReceivedOn: [null],
      firstName: [null, [Validators.required]],
      middleName: [null],
      lastName: [null, [Validators.required]],
      aka: [null],
      deceased: ['0'],
      gender: [null],
      dob: [null],
      ssn: [null],
      raceId: [null],
      collectionDate: [null],
      collectionID: [null],
      collectionSiteId: [null],
      collectorId: [null],
      testPartyIdentifier: [null],
      trackingNumber: [null]
    });
  }


  public get controls() { return this.newCaseForm.controls }

  /* 
   * @desc: For call all the master data need.
   * @author: Abhiram M Sajeev
   */
  getInitialDataList(): void {
    let apiArray = [
      this.caseService.getChannelListingRegular(),
      this.caseService.gettestTypeListing(this.testPerpage, this.testNum),
      this.caseService.getadditionalTestListing(),
      this.caseService.getLanguages(this.pagination), this.caseService.getStateListing("", 1, 100),
      this.caseService.getTestPartyRoles(), this.caseService.getSampleTypes(),
      this.caseService.getTestPartyRace(this.pagination),
      this.caseService.getCollectorSite(this.pagination),
      this.caseService.collectorAgents(this.pagination)
    ];
    this.caseService.forkJoinData(apiArray).subscribe((res: any) => {
      this.onLoadDataList.channelId = res[0]?.data.channels;
      this.onLoadDataList.testType = res[1]?.data;
      this.onLoadDataList.additionalTest = res[2]?.data.additionalTests;
      this.onLoadDataList.language = res[3]?.data.languages;
      this.onLoadDataList.state = res[4]?.data;
      this.onLoadDataList.testPartyRoles = res[5].data.testPartyRoles;
      this.onLoadDataList.sampleType = res[6].data.sampleTypes;
      this.onLoadDataList.testPartyRace = res[7].data.testPartyRaces;
      this.onLoadDataList.collectionSite = res[8].data.collectionSites;
      this.onLoadDataList.collectionAgents = res[9].data.collectionAgents;
      this.stateList = res[4].data.states;
      this.tatCreate();
      this.selectRoles();
      this.createFullName();
    });
  }



  getCollectionsite(req: any) {
    this.caseService.getCollectorSite(req).subscribe(res => {
      this.onLoadDataList.collectionSite = res.data.collectionSites;
    });
  }

  /* 
  * @desc: Collect the selected object and filter the language id form the list for create a new object
  * @author: Elizabeth Mathew
  */
  selectedLanguage(event: any) {
    let temp: { "languageId": number }[] = [];
    this.selectedLanguages = event;
    this.onLoadDataList.language.forEach((item: Languages) => {
      this.selectedLanguages.forEach((item2: Languages) => {
        if (item.langId === item2.langId) {
          let obj = {
            "languageId": item.langId
          }
          temp.push(obj)
        }
      });
    });
    this.newCaseForm.controls.caseReportLang?.setValue(temp);
  }
  /* 
   * @desc: to get list of channels.
   * @author: Elizabeth Mathew
   */
  getChannelList() {
    this.loaderService.isLoaderEnable(true);
    this.caseService.getChannelListing().subscribe(
      (response) => {
        if (response.success) {
          this.channelArrayList = response.data.channels.filter((cType: any) => cType.channelType === "regular");
        } else {
          this.channelArrayList = [];
        }
        this.loaderService.isLoaderEnable(false);
      },
      (err: HttpErrorResponse) => {
        this.loaderService.isLoaderEnable(false);
        this.utility.apiHttpErrorHandler(err);
      }
    );
  }
  /*  
   * @desc: Choose a channel(If user choose gov channel/other channels)the functionalities added here.
   * @author: Elizabeth Mathew
   */
  selectedChannel(event: Channels) {
    this.newCaseForm.controls?.channelId.patchValue(event.channelId);
    this.newCaseForm.controls?.tatId.patchValue(null);
    if (event.channelId !== 1) {
      this.newCaseForm.controls?.stateId.patchValue(null);
      this.newCaseForm.controls?.agencyId.patchValue(null);
      this.newCaseForm.controls?.chain.patchValue(null);
      this.typeEnable = false;
      this.newCaseForm.controls.emboss.patchValue(null);
      this.newCaseForm.controls.affidavit.patchValue(null);
    }
    else {
      this.newCaseForm.controls?.chain.patchValue('1');
      this.typeEnable = true;
      this.newCaseForm.controls.emboss.patchValue('0');
      this.newCaseForm.controls.affidavit.patchValue('1');
    }
    this.languageSelect = [];
  }
  /* 
 * @desc: get all the state lists.
 * @author: Elizabeth Mathew
 */
  getStateList(typeEvent: any) {
    this.caseService.getStateListing(typeEvent, this.StatePerpage, this.statePageSize).subscribe(
      (response) => {
        if (response.success) {
          this.onLoadDataList.state = response.data;
        }
        else {
          this.onLoadDataList.state.states = [];
        }
      },
      (err: HttpErrorResponse) => {
        this.alertandtoaster.alert.toast({
          title: 'Error',
          type: 'error',
          message: err?.error?.message,
        });
      }
    );
  }
  /* 
    * @desc: selected state functionality.
    * @author: Elizabeth Mathew
    */
  selectedState(event: States) {
    this.stateId = event.stateId;
    this.newCaseForm.controls.stateId?.patchValue(this.stateId);
    this.newCaseForm.controls.agencyId?.patchValue(null);
    this.newCaseForm.controls.tatId?.patchValue(null);

    this.onLoadDataList.agencyList = [];
    this.getAgencyList('');

  }

  /* 
  * @desc: get all account details.
  * @author: Elizabeth Mathew
  */
  getAgencyList(TypeEvent: any) {
    this.loaderService.isLoaderEnable(true);
    this.caseService.getAgencyListing(this.stateId, TypeEvent, 1, 100).subscribe(
      (response) => {
        if (response.success) {
          this.onLoadDataList.agencyList = response.data.agencies;
        }
        else {
          this.onLoadDataList.agencyList = [];
        }
        this.loaderService.isLoaderEnable(false);
      },
      (err: HttpErrorResponse) => {
        this.loaderService.isLoaderEnable(false);
        this.utility.apiHttpErrorHandler(err);
      }
    );
  }
  /* 
   * @desc: selected agencies
   * @author: Elizabeth Mathew
   */
  selectedAgencies(event: any) {
    this.newCaseForm.controls.agencyId?.patchValue(event.agencyId);
    this.languageSelect = event.languages;
    this.onLoadDataList.tatType = [];
    this.newCaseForm.controls.tatId.patchValue(event.tatTime);
    if (this.newCaseForm.value.agencyId) {
      const req = {
        "agencyId": this.newCaseForm.value.agencyId,
        "pageNo": 1
      }
      this.getCollectionsite(req);
    }
    let temp: { "languageId": number }[] = [];
    this.languageSelect.forEach((item: any) => {
      let obj = {
        "languageId": item.langId
      }
      temp.push(obj)
    });
    this.newCaseForm.controls.caseReportLang?.setValue(temp);
  }
  /* 
   * @desc: get all tatmaster details.
   * @author: Elizabeth Mathew
   */
  tatMastersList(agencyId: number) {
    this.loaderService.isLoaderEnable(true);
    this.caseService.getTatListing(agencyId).subscribe(
      (response) => {
        if (response.success) {
          this.onLoadDataList.tatType = response.data.tatList;
          this.onLoadDataList.tatType.forEach((item: TatType) => {
            item.tatTimeDisplay = `${item.tatTime}W Day(s)`;
            this.tatTime.push(item)
          });
          this.tatEnable = false;
        }
        else {
          this.onLoadDataList.tatType = [];
        }
        this.loaderService.isLoaderEnable(false);
      },
      (err: HttpErrorResponse) => {
        this.loaderService.isLoaderEnable(false);
        this.utility.apiHttpErrorHandler(err);
      }

    );

  }
  selectedTat(event: TatType) {
    this.newCaseForm.controls?.tatId?.patchValue(event.id);
  }
  /* 
   * @desc: get all testtype details.
   * @author: Elizabeth Mathew
   */
  testTypeList() {
    this.loaderService.isLoaderEnable(true);
    this.caseService.gettestTypeListing(this.testPerpage, this.testNum).subscribe(
      (response) => {
        if (response.success) {
          this.testType = response.data.testSubCategories;
        }
        else {
          this.testType = [];
        }
        this.loaderService.isLoaderEnable(false);
      },
      (err: HttpErrorResponse) => {
        this.loaderService.isLoaderEnable(false);
        this.utility.apiHttpErrorHandler(err);
      }
    );
  }
  selectedTestType(event: TestType) {
    this.newCaseForm.controls?.testTypeId?.setValue(event.testTypeId);
    this.newCaseForm.controls?.testTypeSubCategoryId.setValue("");
    this.subCategoryArrayList = [];
    this.getSubCategory(event.testTypeId);
  }

  /* 
    * @desc: get all subcategory details.
    * @author: Elizabeth Mathew
    */
  getSubCategory(testTypeId: number) {
    this.loaderService.isLoaderEnable(true);
    this.caseService.getSubCategoryData(testTypeId, 1, 100).subscribe(
      (response) => {
        if (response.success) {
          this.subCategoryArrayList = response.data.testSubCategories;
        }
        else {
          this.subCategoryArrayList = [];
        }
        this.loaderService.isLoaderEnable(false);
      },
      (err: HttpErrorResponse) => {
        this.loaderService.isLoaderEnable(false);
        this.utility.apiHttpErrorHandler(err);
      }
    );
  }

  selectedSubcategory(event: TestSubCategories) {
    this.newCaseForm.controls?.testTypeSubCategoryId?.setValue(event.subCategoryId);
  }

  /* 
    * @desc: get all additionaltest details.
    * @author: Elizabeth Mathew
    */
  getAdditionalTest() {
    this.loaderService.isLoaderEnable(true);
    this.caseService.getadditionalTestListing().subscribe(
      (response) => {
        if (response.success) {
          this.AdditioanlTest = response.data;
        }
        else {
          this.testType = [];
        }
        this.loaderService.isLoaderEnable(false);
      },
      (err: HttpErrorResponse) => {
        this.loaderService.isLoaderEnable(false);
        this.utility.apiHttpErrorHandler(err);
      }
    );
  }
  selectedAdditionalTest(event: AdditionalTest) {
    this.newCaseForm.controls?.additionalTestId?.setValue(event.id);
  }
  /* 
   * @desc: get the  userdetails.
   * @author: Elizabeth Mathew
   */
  getUserDetails() {
    this.loaderService.isLoaderEnable(true);
    this.caseService.getUserData().subscribe(
      (response) => {
        if (response.success) {
          this.userDetails = response.data.users[0].userName;
        }
        else {
          this.testType = [];
        }
        this.loaderService.isLoaderEnable(false);
      },
      (err: HttpErrorResponse) => {
        this.loaderService.isLoaderEnable(false);
        this.utility.apiHttpErrorHandler(err);
      }
    );
  }

  /* 
   * @desc: Open collection site modal
   * @author: Abhiram M Sajeev
   */

  selectPartyRoles(value: TestedPartyRoles, index: number) {
    this.selectedRole[index] = value.role;
    (<FormGroup>this.testParties.controls[index]).controls.tpRoleId.patchValue(value.roleId);
  }
  selectSampleType(value: SampleType, index: number) {
    (<FormGroup>this.testParties.controls[index]).controls.sampleTypeId.patchValue(value.id);
  }
  selectdeceased(value: any, index: number) {
    this.deceasedStatus = value.id;
    (<FormGroup>this.testParties.controls[index]).controls.deceased.patchValue(value.id);
  }

  selectGender(value: any, index: number) {
    this.sectetedGender = value.id;
    (<FormGroup>this.testParties.controls[index]).controls.gender.patchValue(value.id);
  }
  selectedRace(value: TestPartyRaces, index: number) {
    (<FormGroup>this.testParties.controls[index]).controls.raceId.patchValue(value.raceId);
  }

  selectedAgent(value: any, index: number) {
    let isExist: boolean = false;
    let dummy = [];
    dummy = [...this.onLoadDataList.collectionAgents]
    this.onLoadDataList.collectionAgents.filter((e: any) => {
      if (e.id === value.id) {
        isExist = true;
      }
    });
    if (!isExist) {
      dummy.unshift(value);
    }
    this.onLoadDataList.collectionAgents = dummy;
    (<FormGroup>this.testParties.controls[index]).controls.collectorId.patchValue(value.id);
  }

  selectedType(value: any) {
    this.newCaseForm.controls.chain.patchValue(value.id);
    this.newCaseForm.controls.stateId.patchValue('')
  }
  /* 
   * @desc: Open collection site modal
   * @author: Abhiram M Sajeev
   */
  selectCollectionSite(index: number) {
    this.isCollectionSite = true;
    this.selectedFormarray = index;
    this.testPartyDetails = { 'role': this.selectedRole[index], 'name': (<FormGroup>this.testParties.controls[index]).controls.firstName.value };
    this.render.addClass(document.getElementById('bodyModal'), 'modal-open');
  }

  openAgentAdvancedSearch(index: number) {
    this.isCollectorAgenetSearch = true;
    this.selectedFormarray = index;
    this.testPartyDetails = { 'role': this.selectedRole[index], 'name': (<FormGroup>this.testParties.controls[index]).controls.firstName.value };
    this.render.addClass(document.getElementById('bodyModal'), 'modal-open');
  }
  /* 
  * @desc: Select collection site from advanced search option
  * @author: Abhiram M Sajeev
  */

  selectedSiteAdvacedSearch(event: any) {
    let isExist: boolean = false;
    let dummy = []
    dummy = [...this.onLoadDataList.collectionSite]
    this.onLoadDataList.collectionSite.filter((e: any) => {
      if (e.id === event.id) {
        isExist = true;
      }
    });
    if (!isExist) {
      dummy.unshift(event);
    }
    this.onLoadDataList.collectionSite = dummy;
    (<FormGroup>this.testParties.controls[this.selectedFormarray]).controls.collectionSiteId.patchValue(event.id);
  }

  selectedCollectionSite(event: any, index: number) {
    (<FormGroup>this.testParties.controls[index]).controls.collectionSiteId.patchValue(event.id);
  }
  /* 
  * @desc: close opened modals
  * @author: Abhiram M Sajeev
  */
  closeModal(value: string) {
    if (value === 'CollectionSite') {
      this.isCollectionSite = false;
    } else {
      this.isCollectorAgenetSearch = false;
    }
    this.render.removeClass(document.getElementById('bodyModal'), 'modal-open');
  }
  /* 
   * @desc: Cahnge the date format to 'YYYY-MM-DD' format
   * @author: Abhiram M Sajeev
   */
  // dateFormat(index: number, controlName: string, value: string) {
  //   (<FormGroup>this.testParties.controls[index]).controls[controlName].patchValue(moment(value).format('YYYY-MM-DD'))  
  // }
  onDateFormat(control: any) {
    if (control.value) {
      control.patchValue(moment(control.value).format('YYYY-MM-DD'));
    }
  }

  /* 
   * @desc: initiate api call create new case
   * @author: Abhiram M Sajeev
   */
  onCreateNewCase() {
    this.isSubmitted = true;
    if (this.newCaseForm.invalid) {
      window.scrollTo(0, 0);
      this.alertandtoaster.alert.toast({
        title: 'Error',
        type: 'error',
        message: 'Please fill the required fileds',
      });
      const error = document.querySelector('.is-invalid');
      if (error) {
        this.scrollTo(error);
      }
      return;
    }
    this.loaderService.isLoaderEnable(true);
    let value = this.newCaseForm.value.testParties;
    let x = [];
    for (let i in value) {
      if ((value[i].firstName !== "" && value[i].firstName !== null) || (value[i].lastName !== "" && value[i].lastName !== null)) {
        x.push(value[i]);
      }
    }
    this.newCaseForm.value.testParties = x;
    const req = this.newCaseForm.value;
    if (localStorage.getItem('docId')) {
      let docItems = localStorage.getItem('docId');
      if (docItems)
        req.docId = JSON.parse(docItems)
    }
    this.caseService.createNewCase(req).subscribe((res) => {
      this.loaderService.isLoaderEnable(false);
      if (res.success) {
        this.alertandtoaster.alert.toast({
          title: 'Success',
          type: 'success',
          message: res?.message,
        });
        this.caseId = res.data.id;
        this.router.navigate([`/case/details/${res.data.id}`]);
        this.isSubmitted = false;
      } else {
        this.alertandtoaster.alert.toast({
          title: 'error',
          type: 'error',
          message: res?.message,
        });
      }
    }, error => {
      this.alertandtoaster.alert.toast({
        title: 'error',
        type: 'error',
        message: error?.message,
      });
      this.loaderService.isLoaderEnable(false);
    });
  }
  /* 
   * @desc: set the value while checkbox box checked
   * @author: Abhiram M Sajeev
   */
  billingTypeChecked(value: any) {
    if (value) {
      this.newCaseForm.controls.isPrivate.patchValue('1')
    } else {
      this.newCaseForm.controls.isPrivate.patchValue(null)
    }
  }

  /* 
   * @desc: create form cancel event
   * @author: Abhiram M Sajeev
   */
  onCancel() {
    this.newCaseForm.reset();
  }

  validationCheck() {
    let testParties: any[] = this.newCaseForm.value.testParties;
    let isValid = false;
    for (let i in testParties) {
      if ((<FormGroup>this.testParties.controls[i]).controls.firstName.value || (<FormGroup>this.testParties.controls[i]).controls.lastName.value) {
        isValid = true;
        break;
      }
    }
    for (let i in testParties) {
      if (isValid) {
        (<FormGroup>this.testParties.controls[i]).controls.firstName.clearValidators();
        (<FormGroup>this.testParties.controls[i]).controls.lastName.clearValidators();
        (<FormGroup>this.testParties.controls[i]).controls.firstName.updateValueAndValidity();
        (<FormGroup>this.testParties.controls[i]).controls.lastName.updateValueAndValidity();
      } else {
        (<FormGroup>this.testParties.controls[i]).controls.firstName.addValidators(Validators.required);
        (<FormGroup>this.testParties.controls[i]).controls.lastName.addValidators(Validators.required);
        (<FormGroup>this.testParties.controls[i]).controls.firstName.updateValueAndValidity();
        (<FormGroup>this.testParties.controls[i]).controls.lastName.updateValueAndValidity();
      }
    }
  }

  /* 
 * @desc: return form array control
 * @author: Abhiram M Sajeev
 */
  formControl(index: number) {
    return (<FormGroup>this.testParties.controls[index]).controls;
  }

  testFunction(value: any) {
    console.log(value);
  }
  getCollectionAgentSearch(value: any) {
    const req = {
      "pageNo": 1,
      "name": value
    }
    this.collectionAgentwithSearchApi(req);
  }

  collectionAgentwithSearchApi(req: { pageNo: number, name?: string }) {
    this.caseService.collectorAgents(req).subscribe((res) => {
      this.onLoadDataList.collectionAgents = res.data.collectionAgents;
      this.createFullName();
    });
  }

  getCollectionsiteSearch(value: any) {
    let req: { pageNo: number, stName: string, agencyId?: number };
    if (this.newCaseForm.value.agencyId) {
      req = {
        "agencyId": this.newCaseForm.value.agencyId,
        "pageNo": 1,
        "stName": value ? value : null
      }
    } else {
      req = {
        "pageNo": 1,
        "stName": value
      }
    }
    this.getCollectionsite(req);
  }

  selectRoles() {
    this.onLoadDataList.testPartyRoles?.filter((element: any) => {
      for (let index in this.newCaseForm.value.testParties)
        if (this.newCaseForm.value.testParties[index].tpRoleId === element.roleId) {
          this.selectedRole[+index] = element.role;
        }
    });
  }
  createFullName() {
    this.onLoadDataList.collectionAgents.forEach((element: any) => {
      let fullName = element.agentName + ' ' + element.agentLastName
      element.agentName = fullName;
    });
  }

  scrollTo(el: Element) {
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      const input: any = el.querySelector('.form-control');
      if (input) {
        input?.focus();
      }
      const firstChild = el.firstChild;
      if (input === firstChild) {
        input?.focus();
      }
    }
  }

  tatCreate(): void {
    this.onLoadDataList.tatList = [];
    for (let i = 0; i <= 45; i++) {
      const obj = {
        'id': i,
        'tatDisplay': i + ' W Day(s)'
      }
      this.onLoadDataList.tatList.push(obj);
    }
  }

  ngOnDestroy() {
    localStorage.removeItem('docId');
  }
}




