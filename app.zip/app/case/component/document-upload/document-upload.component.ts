import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { NgxFileDropEntry, FileSystemFileEntry } from 'ngx-file-drop';
import { AlertandtoasterService } from 'src/app/shared/Services/alertandtoaster.service';
import { TestedPartyRoles, DocumentTypes, DocumentList, Comments } from 'src/app/core/Models/Interfaces/case';
import { Byte } from '@angular/compiler/src/util';
import { CaseService } from '../../services/case.service';
import { HttpErrorResponse } from '@angular/common/http';
import { LoaderService } from 'src/app/core/Services/loader.service';
import { CONSTANTS } from 'src/app/core/Constants/constants';
import { UtilityService } from 'src/app/shared/Services/utility.service';
@Component({
  selector: 'app-document-upload',
  templateUrl: './document-upload.component.html',
  styleUrls: ['../../../../assets/style/css/case.css'],
})
export class DocumentUploadComponent implements OnInit {

  @Input() caseId: number = 0;
  constants = CONSTANTS.docCategory;
  prevId: number = 0;
  docId: number = 0;
  fileData: File | null = null;
  docComments!: string;
  commentSection: string = '';
  fileSize: string = '';
  fileName: string = '';
  newDoc: boolean = false;
  categoryBtnInt: boolean = false;
  categoryBtnExt: boolean = false;
  hideFileUpload: boolean = false;
  showAddNewBtn: boolean = false;
  btnEnable: boolean = false;
  prevDocShow: boolean = false;
  edit: boolean = false;
  submitted: boolean = false;
  showSlider: boolean = false;
  docArray: DocumentTypes[] = [];
  testedPartyArray: TestedPartyRoles[] = [];
  selectedParites: TestedPartyRoles[] = [];
  selectedDocs: DocumentTypes[] = [];
  public files: NgxFileDropEntry[] = [];
  documentList: DocumentList[] = [];
  uploadDocObj: string[] = [];
  commentList: Comments[] = [];
  @Output() close: EventEmitter<boolean> = new EventEmitter<boolean>();

  constructor(
    private alertandtoaster: AlertandtoasterService,
    private caseService: CaseService,
    public loader: LoaderService,
    private utility: UtilityService
  ) {
    this.loader.isContentLoader(true);
  }

  ngOnInit(): void {
    let obj = {
      pageNo: 1
    }
    this.caseService.forkJoinData([this.caseService.getDocumentTypes(obj), this.caseService.getTestPartyRoles()]).subscribe((res) => {
      this.getDocumentTypes(res[0]);
      this.getTestPartyRoles(res[1]);
    },
      (error: HttpErrorResponse) => {
        this.testedPartyArray = [];
        this.utility.apiHttpErrorHandler(error);
        this.loader.isContentLoader(false);
      })

    if (this.caseId) {
      localStorage.removeItem('docId');
      this.getDocumentList();
    }
    else if (localStorage.getItem('docId')) {
      let docItems = localStorage.getItem('docId');
      if (docItems) {
        this.uploadDocObj = [];
        JSON.parse(docItems).forEach((el: any) => {
          if (el) this.uploadDocObj.push((el))
        })
      }
      if (this.uploadDocObj.length) {
        this.getDocumentList();
      }
    }
    this.enableFileUploadBtn();
  }


  ngAfterViewInit() {
    setTimeout(() => { this.showSlider = true; });
  }
  /*
   * @desc: to close
   * @author: Nilena Alexander
   */
  closeBtn() {
    setTimeout(() => { this.close.emit(false); }, 400);
    this.showSlider = false;
  }

  /*
  * @desc: to dropped file
  * @author: Nilena Alexander
  */
  public dropped(files: NgxFileDropEntry[]) {
    for (const droppedFile of files) {
      if (droppedFile.fileEntry.isFile) {
        const fileEntry = droppedFile.fileEntry as FileSystemFileEntry;
        fileEntry.file((file: File) => {
          let size = Number(file.size) / 1048576;
          let typeSize = droppedFile.relativePath.split('.');
          this.checkFileSize(size, typeSize, file);
        });
      } else {
        this.deleteDropedItem();
      }
    }
  }
  /*
  * @desc: to  check file size
  * @author: Nilena Alexander
  */
  checkFileSize(size: number, typeSize: any, file: File) {
    if (size <= 5 &&
      (typeSize[typeSize.length - 1].toUpperCase() === 'JPG' ||
        typeSize[typeSize.length - 1].toUpperCase() === 'JPEG' ||
        typeSize[typeSize.length - 1].toUpperCase() === 'PDF' ||
        typeSize[typeSize.length - 1].toUpperCase() === 'PNG')) {
      this.hideFileUpload = true;
      this.fileData = file;
      this.fileSize = this.formatBytes(file.size);
      this.fileName = file.name;
      if (this.edit) {
        this.newDoc = true;
      }
      else {
        this.newDoc = false;
      }
      this.enableFileUploadBtn();

    } else {
      if (size > 5) {
        this.alertandtoaster.alert.toast({
          title: 'Error',
          type: 'error',
          message: 'Max size 5Mb',
        });
      } else {
        this.alertandtoaster.alert.toast({
          title: 'Error',
          type: 'error',
          message: 'Invalid file type. PDF or Image will be supported',
        });
      }
    }
  }
  /*
  * @desc: to  get document type list api
  * @author: Nilena Alexander
  */
  getDocumentTypes(res: any) {
    if (res.success === true) {
      this.docArray = res.data.documentTypes;
      this.loader.isLoaderEnable(false);
    } else {
      this.alertandtoaster.alert.toast({
        title: 'Error',
        type: 'error',
        message: res?.message,
      });
      this.loader.isLoaderEnable(false);
    }
  }

  /*
  * @desc: to  call api for testparty roles
  * @author: Nilena Alexander
  */
  getTestPartyRoles(res: any) {
    if (res.success === true) {
      this.testedPartyArray = res.data.testPartyRoles;
      this.loader.isLoaderEnable(false);
    } else {
      this.alertandtoaster.alert.toast({
        title: 'Error',
        type: 'error',
        message: res?.message,
      });
      this.loader.isLoaderEnable(false);
    }

  }
  /*
  * @desc  : to upload ddocuments
  * @author: Nilena Alexander
  */

  objectCreation(formData: FormData) {
    this.submitted = true;
    if (this.fileData)
      formData.append('doc', this.fileData);
    if (this.caseId) {
      formData.append('caseId', JSON.stringify(this.caseId ? Number(this.caseId) : null));
    }
    if (this.categoryBtnInt)
      formData.append('category', this.constants.internal);
    else if (this.categoryBtnExt)
      formData.append('category', this.constants.external);
    else
      formData.append('category', this.constants.all);

    formData.append('comment', this.commentSection);
    formData.append('docTypeIds', this.selectedDocs?.toString());
    formData.append('tstPartyRoleIds', this.selectedParites?.toString());
    if (this.edit && this.docId) {
      formData.append('docId', JSON.stringify(this.docId ? Number(this.docId) : null));
    }
    formData.append('isNewDoc', JSON.stringify(this.newDoc));

  }


  docsUpload() {
    this.loader.isContentLoader(true);
    const formData = new FormData();

    this.objectCreation(formData);
    if (!this.edit) {
      this.caseService.uploadDocument(formData).subscribe(response => {
        if (response.success === true) {
          this.alertandtoaster.alert.toast({
            title: 'Success',
            type: 'success',
            message: response?.message,
          })
          if (response.data) {
            if (!this.caseId) {
              this.uploadDocObj.push((response.data.id))
              localStorage.setItem('docId', JSON.stringify(this.uploadDocObj));
            }
          }
          this.showAddNewBtn = false;
          this.submitted = false;
          this.cancelDropedItem();
          this.getDocumentList();
          this.loader.isContentLoader(false);
        } else {
          this.submitted = false;
          this.alertandtoaster.alert.toast({
            title: 'Error',
            type: 'error',
            message: response?.message,
          });
          this.loader.isContentLoader(false);
        }
      }, (errorr: HttpErrorResponse) => {
        this.submitted = false;
        this.utility.apiHttpErrorHandler(errorr);
        this.loader.isContentLoader(false);
      })
    } else {
      this.updateDoc(formData);
    }

  }

  /*
  * @desc  : to enable check fileupload button file
  * @author: Nilena Alexander
  */

  enableFileUploadBtn() {
    if (this.hideFileUpload) {
      this.btnEnable = true;
    } else {
      this.btnEnable = false;
    }
  }

  /*
   * @desc: to get
   * @author: Nilena Alexander
   */
  testPartySelected(event: TestedPartyRoles[]) {
    if (event) {
      this.selectedParites = [];
      event.forEach((element: any) => {
        this.selectedParites.push(element.roleId);
      });
      this.enableFileUploadBtn();
    }
  }


  /*
   * @desc: to get selected docs
   * @author: Nilena Alexander
   */
  documentSelected(event: any) {
    if (event) {
      this.selectedDocs = [];
      event.forEach((element: any) => {
        this.selectedDocs.push(element.id);
      });
      this.enableFileUploadBtn();
    }
  }

  /*
   * @desc: to convert bites to Byte
   * @author: Nilena Alexander
   */
  formatBytes(bytes: Byte, decimals = 2) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
  }

  /*
   * @desc: to delete dropped item
   * @author: Nilena Alexander
   */
  deleteDropedItem() {
    this.hideFileUpload = false;
    this.fileSize = '';
    this.fileData = null;
    this.fileName = '';
    this.newDoc = false;
    this.enableFileUploadBtn();
  }
  /*
  * @desc: to delete dropped item
  * @author: Nilena Alexander
  */
  cancelDropedItem() {
    this.hideFileUpload = false;
    this.fileSize = '';
    this.fileData = null;
    this.categoryBtnInt = false;
    this.categoryBtnExt = false;
    this.edit = false;
    this.newDoc = false;
    this.selectedDocs = [];
    this.selectedParites = [];
    this.commentSection = '';
    this.fileName = '';
    this.docComments = '';
    this.enableFileUploadBtn();
  }

  /*
   * @desc: to get documentList
   * @author: Nilena Alexander
   */
  getDocumentList() {
    let obj;
    if (this.caseId) {
      obj = {
        pageNo: 1,
        caseId: this.caseId ? this.caseId : null
      }
    } else {
      obj = {
        pageNo: 1,
        docIds: this.uploadDocObj.length ? (this.uploadDocObj).toString() : null,
      }
    }

    this.caseService.getCaseList(obj).subscribe((res) => {
      if (res && res.success) {
        this.loopingRolesandDoc(res.data.documents);

        this.loader.isContentLoader(false);
      }
      else {
        this.afterResponseFn();
        this.alertandtoaster.alert.toast({
          title: 'Error',
          type: 'error',
          message: res?.message,
        });
        this.loader.isContentLoader(false);
      }
    }, (err: HttpErrorResponse) => {
      this.afterResponseFn();
      this.utility.apiHttpErrorHandler(err);
      this.loader.isContentLoader(false);
    })
  }

  afterResponseFn() {
    this.documentList = [];
    if (!this.caseId) {
      this.uploadDocObj = [];
      localStorage.setItem('docId', JSON.stringify(this.uploadDocObj));
    }
  }
  /*
   * @desc: to looping roles and document
   * @author: Nilena Alexander
   */
  loopingRolesandDoc(res: any) {
    for (let row of res) {
      for (let _row1 of row.documentTypes) {
        if (row.documentTypes[0])
          row.doc1st = row.documentTypes[0].documentType;

        if (row.testPartyRoles[0])
          row.test1st = row.testPartyRoles[0].role;
      }
    }
    this.documentList = res;
    if (!this.caseId) {
      if (res.length) {
        this.uploadDocObj = [];
        this.uploadDocObj = res.map((item: DocumentList) => {
          return (item.documentId)
        })
      } else {
        this.uploadDocObj = [];
      }
      localStorage.setItem('docId', JSON.stringify(this.uploadDocObj));
    }
  }

  /*
   * @desc: to download pdf
   * @author: Nilena Alexander
   */
  downloadPdf(item: DocumentList) {
    this.loader.isContentLoader(true);
    this.caseService.doumentDetails(item.documentId, 'download').subscribe((res) => {
      if (res && res.success) {
        this.utility.fileChangeEvent(res.data.document, false);
        this.loader.isContentLoader(false);
      }
      else {
        this.alertandtoaster.alert.toast({
          title: 'Error',
          type: 'error',
          message: res?.message,
        });
        this.loader.isContentLoader(false);
      }
    }, (err: HttpErrorResponse) => {
      this.httpError(err);
    })
  }

  /*
   * @desc: to download pdf
   * @author: Nilena Alexander
   */
  getDocComments(item: DocumentList) {
    this.loader.isContentLoader(true);
    this.documentList.forEach(el => {
      if (Number(item.documentId) !== (Number(el.documentId))) {
        el.commentSectionOpen = false;
      }
    })
    let obj = {
      pageNo: 1,
    }
    this.caseService.doumentDetails(item.documentId, 'comments', obj).subscribe((res) => {
      if (res && res.success) {
        this.commentList = res.data.comments;
        this.loader.isContentLoader(false);
      }
      else {
        this.commentList = [];
        this.alertandtoaster.alert.toast({
          title: 'Error',
          type: 'error',
          message: res?.message,
        });
        this.loader.isContentLoader(false);
      }
    }, (err: HttpErrorResponse) => {
      this.commentList = [];
      this.utility.apiHttpErrorHandler(err);
      this.loader.isContentLoader(false);
    })
  }


  /*
   * @desc: to print documents
   * @author: Nilena Alexander
   */
  print() {
    window.print();
  }

  /*
   * @desc: to check type
   * @author: Nilena Alexander
   */
  onRadioClick(type: string) {
    if (type === this.constants.internal) {
      this.categoryBtnInt = !this.categoryBtnInt;
      if (this.categoryBtnExt) {
        this.categoryBtnExt = false;
      }
    }
    if (type === this.constants.external) {
      this.categoryBtnExt = !this.categoryBtnExt;
      if (this.categoryBtnInt) {
        this.categoryBtnInt = false;
      }
      this.enableFileUploadBtn();
    }
  }
  /*
   * @desc: to check type
   * @author: Nilena Alexander
   */
  addComments(item: DocumentList) {
    this.loader.isContentLoader(true);
    let obj = {
      docId: item.documentId,
      comment: this.docComments
    }
    this.caseService.addingComments(obj).subscribe(res => {
      if (res && res.success) {
        this.alertandtoaster.alert.toast({
          title: 'Success',
          type: 'success',
          message: res?.message,
        });
        this.docComments = '';
        this.getDocumentList();
        this.loader.isContentLoader(false);
      }
      else {
        this.docComments = '';
        this.alertandtoaster.alert.toast({
          title: 'Error',
          type: 'error',
          message: res?.message,
        });
        this.loader.isContentLoader(false);
      }
    }, (err: HttpErrorResponse) => {
      this.docComments = '';
      this.docComments = '';
      this.utility.apiHttpErrorHandler(err);
      this.loader.isContentLoader(false);
    })
  }
  /*
   * @desc: to check type
   * @author: Nilena Alexander
   */
  gotoPreviewPage(item: DocumentList) {
    this.prevId = item.documentId;
    this.prevDocShow = true;
  }
  /*
  * @desc: to delete a doc
  * @author: Nilena Alexander
  */

  deleteDoc(item: DocumentList) {
    this.loader.isContentLoader(true);
    this.caseService.deleteDoc(item.documentId).subscribe((res) => {
      if (res && res.success) {
        this.alertandtoaster.alert.toast({
          title: 'Success',
          type: 'success',
          message: res?.message,
        });
        this.getDocumentList();
        this.loader.isContentLoader(false);
      }
      else {
        this.documentList = [];
        this.alertandtoaster.alert.toast({
          title: 'Error',
          type: 'error',
          message: res?.message,
        });
        this.loader.isContentLoader(false);
      }
    }, (err: HttpErrorResponse) => {
      this.httpError(err);
    })
  }

  /*
  * @desc: common fun to errorhandler
  * @author: Nilena Alexander
  */
  httpError(err: HttpErrorResponse) {
    this.documentList = [];
    this.utility.apiHttpErrorHandler(err);
    this.loader.isContentLoader(false);
  }

  /*
  * @desc: cto edit a particular document
  * @author: Nilena Alexander
  */
  editDoc(item: DocumentList) {
    this.documentList = [];
    this.showAddNewBtn = true;
    this.edit = true;
    this.docId = item.documentId;
    this.caseService.doumentPreview(item.documentId).subscribe((res) => {
      if (res && res.success) {
        if (res.data.document.category === this.constants.internal) {
          this.categoryBtnExt = false;
          this.categoryBtnInt = true;
        } else if (res.data.document.category === this.constants.external) {
          this.categoryBtnExt = true;
          this.categoryBtnInt = false;
        }
        else {
          this.categoryBtnExt = false;
          this.categoryBtnInt = false;
        }
        this.selectedDocs = [];
        if (res.data.document.documentTypes.length) {
          this.selectedDocs = res.data.document.documentTypes.map((el: DocumentTypes) => {
            return (el.id)
          })
        }

        if (res.data.document.testPartyRoles.length) {
          this.selectedParites = res.data.document.testPartyRoles.map((el: TestedPartyRoles) => {
            return (el.roleId)
          })
        }
        this.commentSection = '';
        this.hideFileUpload = true;
        this.fileName = res.data.document.documentFileName;
        this.fileSize = res.data.document.documentFileSize;
        this.enableFileUploadBtn();
        this.loader.isContentLoader(false);
      }
      else {
        this.edit = false;
        this.documentList = [];
        this.showAddNewBtn = false;
        this.getDocumentList();
        this.alertandtoaster.alert.toast({
          title: 'Error',
          type: 'error',
          message: res?.message,
        });
        this.loader.isContentLoader(false);
      }
    }, (err: HttpErrorResponse) => {
      this.documentList = [];
      this.edit = false;
      this.showAddNewBtn = false;
      this.getDocumentList();
      this.utility.apiHttpErrorHandler(err);
      this.loader.isContentLoader(false);
    })
  }

  /*
  * @desc: to cancel add
  * @author: Nilena Alexander
  */
  cancel() {
    if (this.caseId) {
      localStorage.removeItem('docId');
      this.getDocumentList();
    }
    else if (localStorage.getItem('docId')) {
      let docItems = localStorage.getItem('docId');
      if (docItems) {
        this.uploadDocObj = [];
        JSON.parse(docItems).forEach((el: any) => {
          if (el) this.uploadDocObj.push((el))
        })
      }
      if (this.uploadDocObj.length) {
        this.getDocumentList();
      }
      else {
        this.showAddNewBtn = false;
      }
    }
    this.showAddNewBtn = false;
    this.cancelDropedItem();
  }


  /*
  * @desc: to cancel add
  * @author: Nilena Alexander
  */

  updateDoc(formData: FormData) {
    this.loader.isContentLoader(true);
    this.caseService.updateDoc(formData).subscribe(res => {
      if (res.success) {
        this.alertandtoaster.alert.toast({
          title: 'Success',
          type: 'success',
          message: res?.message,
        })
        this.showAddNewBtn = false;
        this.submitted = false;
        this.cancelDropedItem();
        this.getDocumentList();
        this.loader.isContentLoader(false);
      } else {
        this.alertandtoaster.alert.toast({
          title: 'Error',
          type: 'error',
          message: res?.message,
        });
        this.loader.isContentLoader(false);

      }

    })
  }
}
