export interface ApiResponse {
  success: boolean;
  message: string;
  code: string;
  data: any;
}
