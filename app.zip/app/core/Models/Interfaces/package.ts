
/* Updated according to API
 * ApiResponse
 *  Channels
*/

export interface Channels{
    allowNotification?: boolean,
    channelAbbr?: string,
    channelId ?: number,
    channelName?: string,
    cssClassName?: string,
    defaultEmail: string,
    channelType? : string
}
export interface ScanedItems{
  slNo:number,
  trackingNumber:string,
  tat?:string,
  channelObj?:Channels,
  comments?:string,
  intakeId:number,
  trackingId:number,
  userId?:number
}


export interface CourierAgntList{
    courierId: number,
    courierName: string,
}


export interface Channels{
    id : number,
    channel :string,
    colorCode : string,
    type? : string
}

export interface PackageLisingResponse {
  success: boolean,
  message: string,
  code: number,
  data: PackageResponsePayload,
}

export interface UserdetailsResponse  {
  success: boolean,
  message: string,
  code: number,
  data: {
    users: UserPayload[]
  }
}


export interface SaveTrackingItem{
  intakeId:number |null,
  trackingNumber: string,
  courierId: number
}
export interface ChanneUpdateRequest {
  intakeId: number,
  trackingNumber: string,
  channelId: number
}

export interface AddComments{
  trackingId: number,
  comment?: string,
  userId?: number,
  flag: boolean
}

export interface AddNotificationPayload{
  trackingId: number,
  notifyTo : string,
  message : string,
  userId?: number,
}

export interface UserPayload {
  userId: number,
  userFullName: string,
  userName: string
}
export interface Receipt {
  receiptPdfEncoded: string,
  receiptPdfFileName: string,
  receiptPdfResponseMessage?:string,
  receiptPdfSignature:string
}

export interface TrackingItemsPayload {
  trackId: number,
  tat: string,
  channels: Channels,
  trackingNumber: string
  trackingComments: CommentsPayload[]
}

export interface PackagesPayaload {
  inTakeId: number,
  courierName: string,
  intakeTime: string,
  intakePerson: string,
  channels: ChannelsPayaload[],
  trackings: TrackingItemsPayload[],
  isExpandRow?:boolean
}

export interface PackageResponsePayload {
  totalElements: number,
  totalPages: number,
  packages: PackagesPayaload[];
}

export interface CommentsPayload {
  id: number,
  content: string,
  person: string,
  time: string
}

export interface ChannelsPayaload {
  channel: string,
  channelCount: string,
  channelId: string
}

export interface TestSubCategories{
  subCategoryId: number,
  subCategory : string
}
export interface DocTypeAPI{
  documentTypes: DocumentTypes,
  totalElements: number,
  totalPages:number
}

export interface DocumentTypes{
  documentType:string,
  id:number
}