import { PackageListigRequest } from './package-listig-request';

describe('PackageListigRequest', () => {
  it('should create an instance', () => {
    expect(new PackageListigRequest()).toBeTruthy();
  });
});
