import { Injectable } from '@angular/core';
import { JwtHandlerService } from './jwt-handle/jwt-handler.service';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
 decodeToken :string=
      'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c';
  constructor( private jwtService: JwtHandlerService) {
   }

   setToken(){
    this.jwtService.setUserTtoken(this.decodeToken);
   }

 
}
