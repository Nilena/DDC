import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoaderService {
 public isLoader$ = new BehaviorSubject<boolean>(false);
 public contentLoader$ = new BehaviorSubject<boolean>(false);

  public getLoader(): Observable<boolean>{
      return this.isLoader$.asObservable();
    }

  public isLoaderEnable(value: boolean) {
      return this.isLoader$.next(value);
   }

  public getContentLoader(): Observable<boolean> {
    return this.contentLoader$.asObservable();
  }

  public isContentLoader(value: boolean) {
    return this.contentLoader$.next(value);
  }
}
