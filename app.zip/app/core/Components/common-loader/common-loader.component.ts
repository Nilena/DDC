import { Component, OnDestroy } from '@angular/core';
import { LoaderService } from '../../Services/loader.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-common-loader',
  templateUrl: './common-loader.component.html',
  styleUrls: ['./common-loader.component.css']
})
export class CommonLoaderComponent implements OnDestroy {
  subscription: Subscription;
  isLoader: boolean = false;

  constructor(private loaderService: LoaderService) { 
    this.subscription = this.loaderService.getLoader().subscribe((res)=> {
      this.isLoader = res;
    })
  }


  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
}
