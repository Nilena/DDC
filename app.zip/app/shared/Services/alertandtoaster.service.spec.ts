import { TestBed } from '@angular/core/testing';

import { AlertandtoasterService } from './alertandtoaster.service';

describe('AlertandtoasterService', () => {
  let service: AlertandtoasterService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AlertandtoasterService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
