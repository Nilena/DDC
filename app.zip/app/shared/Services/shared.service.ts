import { Injectable } from '@angular/core';
import { getApiUrl, apiList } from 'src/app/core/Constants/apilist';
import { HttpClient } from '@angular/common/http';
import { ApiResponse } from 'src/app/core/Models/Interfaces/commonInterface';
import { Observable } from 'rxjs';
import { AddComments, AddNotificationPayload } from '../../core/Models/Interfaces/package'

@Injectable({
  providedIn: 'root'
})
export class SharedService {

  constructor(
    private http: HttpClient,

  ) { }

  /*
   * @Desc   : API call for getting comments giving tracking ID.
   * @Author : Arjun S
   * @Param  : Tracking ID
   */
  getCommentsForTrackingId(trackingId: number) {
    let endpoint = getApiUrl(apiList.package.getTracking + `/${trackingId}/comments`);
    return this.http.get<ApiResponse>(endpoint);
  }

  /*
   * @ Desc   : API call for getting notifications giving tracking ID.
   * @ Author : Arjun S
   * @ Param  : Tracking ID
   */
  getNotificationsForTrackingId(trackingNumber: number) {
    let endpoint = getApiUrl(apiList.package.getTracking + `/${trackingNumber}/notifications`);
    return this.http.get<ApiResponse>(endpoint);
  }

  /*
   * @ Desc   : API call for getting contacts giving channel ID.
   * @ Author : Arjun S
   * @ Param  : Channel ID
   */
  getEmailsForChannelId(channelId: number) {
    let endpoint = getApiUrl(apiList.package.getEmailList + `/${channelId}/contacts`);
    return this.http.get<ApiResponse>(endpoint);
  }


  /*
   * @ Desc   : API call for posting comments from comment slider component.
   * @ Author : Arjun S
   * @ Param  : Payload containing message body.
   */
  addComments(payload: AddComments): Observable<ApiResponse> {
    let endpoint = getApiUrl(apiList.package.getComments);
    return this.http.post<ApiResponse>(endpoint, payload);
  }

  /*
   * @ Desc   : API call for posting notifications from comment slider component.
   * @ Author : Arjun S
   * @ Param  : Payload containing message body.
   */
  addNotifications(payload: AddNotificationPayload): Observable<ApiResponse> {
    let endpoint = getApiUrl(apiList.package.postNotifications);
    return this.http.post<ApiResponse>(endpoint, payload);
  }



}
