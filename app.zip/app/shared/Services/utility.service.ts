import { Injectable } from '@angular/core';
import { HttpErrorResponse } from '@angular/common/http';
import { AlertandtoasterService } from './alertandtoaster.service';
import { DomSanitizer } from '@angular/platform-browser';
declare let require: any;
const FileSaver = require('file-saver');
@Injectable({
  providedIn: 'root'
})
export class UtilityService {

  constructor(private alertandtoaster: AlertandtoasterService,
    private sanitizer: DomSanitizer) {

  }

  /*
 * @desc : Dispaly toaster message http error 
 * @author Manaf
 */

  apiHttpErrorHandler(err: HttpErrorResponse) {
    this.alertandtoaster.alert.toast({
      title: 'Error',
      type: 'error',
      message: err?.error?.message,
    });
  }

  /*
 * @Desc   : converted blob to pdf
 * @Author : Nilena Alexander
 * @Param  : encodedata,filename and type of file
 */
  fileChangeEvent(fileInput: any, iframe: boolean) {
    let byteCharacters = atob(fileInput.docEncoded);
    let byteNumbers = new Array(byteCharacters.length);
    for (let i = 0; i < byteCharacters.length; i++) {
      byteNumbers[i] = byteCharacters.charCodeAt(i);
    }
    let byteArray = new Uint8Array(byteNumbers);
    let type: string = '';
    if (fileInput.docType === "png" || fileInput.docType === "jpg" || fileInput.docType === "jpeg") {
      type = 'image/png';
    }
    else if (fileInput.docType === "pdf") {
      type = 'application/pdf';
    }
    let file = new Blob([byteArray], { type: type });
    if (!iframe){
      FileSaver.saveAs(file, fileInput.documentFileName);
      return true
    }
    else {
      let fileURL = URL.createObjectURL(file);
      return this.sanitizer.bypassSecurityTrustResourceUrl(fileURL);
    }


  }



}
