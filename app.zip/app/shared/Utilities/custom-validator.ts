import { AbstractControl, ValidationErrors } from '@angular/forms';
import * as moment from 'moment';

export class CustomValidation {
  /*
    desc   : for Email Validation
    */
  public static email(control: AbstractControl) {
    if (control.value) {
      const email = control.value; // to get value in input tag
      const pattern = new RegExp(
        /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,3}))$/
      );
      if (email && !pattern.test(email)) {
        return { invalidEmail: true };
      }
      return null;
    } else {
      return null;
    }
  }
  /*
        desc   :for alpha checking only
      */
  public static alphabets(control: AbstractControl) {
    if (control.value) {
      const text = control.value; // to get value in input tag
      const pattern = new RegExp(/^[a-zA-Z ]+$/);
      if (!pattern.test(text)) {
        return { alphabetsOnly: true };
      } else {
        return null;
      }
    } else {
      return null;
    }
  }
  /*
   desc   : for mobile Validation
   */
  public static mobileNum(control: AbstractControl) {
    const text = control.value; // to get value in input tag
    const pattern = new RegExp(/^(\+\d{1,3}[- ]?)?\d{10,12}$/);
    if (!pattern.test(text)) {
      return { invalidMobile: true };
    } else {
      return null;
    }
  }
  /*
        desc   :for checking description only
      */
  public static discriptionText(control: AbstractControl) {
    if (control.value) {
      const text = control.value; // to get value in input tag
      const pattern = new RegExp(/^[a-zA-Z\.&\s]+$/);
      if (!pattern.test(text)) {
        return { discriptionText: true };
      } else {
        return null;
      }
    } else {
      return null;
    }
  }
  /*
        desc   :for checking decimal number only
      */

  public static floatingNumber(control: AbstractControl) {
    if (control.value) {
      const floatingNumber = control.value; // to get value in input tag
      const pattern = new RegExp(/^[+-]?([0-9]*[.])?[0-9]+$/);
      if (
        !pattern.test(floatingNumber) &&
        (control.value !== '' || control.value != null)
      ) {
        return { floatingNumber: true };
      } else {
        return null;
      }
    } else {
      return null;
    }
  }
  /*
        desc   :for checking number only
      */
  public static onlyNumber(control: AbstractControl) {
    if (control.value) {
      const onlyNumber = control.value; // to get value in input tag
      const pattern = new RegExp(/^[0-9]*$/);
      if (!pattern.test(onlyNumber)) {
        return { onlyNumber: true };
      } else {
        return null;
      }
    } else {
      return null;
    }
  }
  /*
       desc   :for checking number amd decimal only
     */
  public static numberWithDecimal(control: AbstractControl) {
    if (control.value) {
      const onlyNumber = control.value; // to get value in input tag
      const pattern = new RegExp(/^[0-9]*(\.[0-9]{0,2})?$/);
      if (!pattern.test(onlyNumber)) {
        return { onlyNumber: true };
      } else {
        return null;
      }
    } else {
      return null;
    }
  }
  // ^\d+\.\d{0,2}$
  /*
        desc   :for checking input contain password
      */
  public static PasswordRule(control: AbstractControl) {
    if (control.value) {
      const password = control.value; // to get value in input tag
      const pattern = new RegExp(
        '^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{8,64}'
      );
      if (password && !pattern.test(password)) {
        return { passwordRule: true };
      }
      return null;
    } else {
      return null;
    }
  }
  /*
        desc   :for checking input contain space
      */

  public static cannotContainSpace(
    control: AbstractControl
  ): ValidationErrors | null {
    // set error on matchingControl if validation fails
    if (control.value) {
      if (control.value && control.value.indexOf(' ') > -1) {
        return { cannotContainSpace: true };
      } else {
        return null;
      }
    } else {
      return null;
    }
  }
  /*
        desc   :for checking input has no space
      */
  public static noSpaceOnly(control: AbstractControl): ValidationErrors | null {
    if (control.value && control.value.trim() === '') {
      return { required: true };
    } else {
      return null;
    }
  }
  /*
        desc   :for checking input has future dates
      */
  public static futureDate(control: AbstractControl): ValidationErrors | null {
    try {
      let today = new Date().getTime();
      let date = control.value ? new Date(control.value).getTime() : null;
      if (date && date > today) {
        return { futureDate: true };
      }
    } catch (err) {
      return null;
    }
    return null;
  }
  /*
         desc   :for checking input has valid dates
    */
  public static validDate(control: AbstractControl): ValidationErrors | null {
    try {
      let date = control.value ? new Date(control.value).getTime() : null;
      if (!date) {
        return { validDate: true };
      }
      if (date) {
        if (!moment(control.value, 'MM/DD/YYYY').isValid()) {
          return { validDate: true };
        }
      }
    } catch (err) {
      return null;
    }
    return null;
  }

  /*
        author :Arjun
        desc   :for checking min date is 1899
    */

  public static OldDate(control: AbstractControl): ValidationErrors | null {
    try {
      let date = control.value ? new Date(control.value).getTime() : null;
      if (date) {
        let timestamp = Date.parse(control.value);
        let dateObject = new Date(timestamp);
        let dateYear = dateObject.getFullYear();
        if (dateYear < 2000) {
          return { inValidrange: true };
        }
      }
    } catch (err) {
      return null;
    }
    return null;
  }
}
