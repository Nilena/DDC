import { Component, EventEmitter, Input, OnChanges, Output, SimpleChanges } from '@angular/core';
import { FormControl } from '@angular/forms';


@Component({
  selector: 'app-select-with-search',
  templateUrl: './select-with-search.component.html',
  styleUrls: ['./select-with-search.component.css']
})
export class SelectWithSearchComponent implements  OnChanges {
 @Output()
 selectValue = new EventEmitter<any>();
 @Input() 
 cssClass: string = '';
 @Input() 
 defaultSelect: string | number = '';
 @Input() 
 value: string | number = ''
 @Input() 
 dispalyValue: string | number = ''
 @Input() 
 palceHolder: string = 'Select'
 @Input() 
 dataArr: any [] = []
 selectedValue = new FormControl(this.defaultSelect);

  ngOnChanges(changes: SimpleChanges): void {
    this.selectedValue.patchValue(this.defaultSelect);
  }
  onChange(value: any){
    this.selectValue.emit(value.target.value);
  }
}
