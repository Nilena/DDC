import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmailDropdownComponentComponent } from './email-dropdown-component.component';

describe('EmailDropdownComponentComponent', () => {
  let component: EmailDropdownComponentComponent;
  let fixture: ComponentFixture<EmailDropdownComponentComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EmailDropdownComponentComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EmailDropdownComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
