import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AutocompeleteMultiselectComponent } from './autocompelete-multiselect.component';

describe('AutocompeleteMultiselectComponent', () => {
  let component: AutocompeleteMultiselectComponent;
  let fixture: ComponentFixture<AutocompeleteMultiselectComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AutocompeleteMultiselectComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AutocompeleteMultiselectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
