import { Component, OnInit, Input } from '@angular/core';
import { Observable } from 'rxjs';
import { FormControl } from '@angular/forms';
import { startWith, map } from 'rxjs/operators';

@Component({
  selector: 'app-autocompelete-multiselect',
  templateUrl: './autocompelete-multiselect.component.html',
  styleUrls: ['./autocompelete-multiselect.component.css']
})
export class AutocompeleteMultiselectComponent implements OnInit {

  @Input() defaultEmail : string = '';

  myControl = new FormControl();
  options: string[] = ['sample@gmail.com', 'asample@gmail.com', 'bsample@gmail.com'];
  filteredOptions !: Observable<string[]>;

  ngOnChanges(){
    this.myControl.patchValue(this.defaultEmail);
  }

  ngOnInit(): void {
    this.filteredOptions = this.myControl.valueChanges
    .pipe(
      startWith(''),
      map(value => this._filter(value))
    );
  }

  private _filter(value: string): string[] {
    const filterValue = value.toLowerCase();

    return this.options.filter(option => option.toLowerCase().includes(filterValue));
  }

}
