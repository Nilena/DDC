import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'appFiltersearch'
})
export class SearchPipe implements PipeTransform {

  // transform(value: unknown, ...args: unknown[]): unknown {
  //   return null;
  // }
 /**
   * Transform
   *
   * @param {any[]} items
   * @param {string} searchText
   * @returns {any[]}
   */
  transform(array: any[], searchText: string, label1?:any,label2?:any,label3?:any): any[] {
    if (!array) {
      return [];
    }
    if (!searchText) {
      return array;
    }
    searchText = searchText.toLocaleLowerCase();
    if (label1 || label2 ||label3) {
      return array.filter(item => 
       (label2? ((item[label2] as string).toLocaleLowerCase().includes(searchText)):'')||
        (label1? ((item[label1] as string).toLocaleLowerCase().includes(searchText)):'') ||
         (label3?( (item[label3] as string).toLocaleLowerCase().includes(searchText)):'') );
    }
     else {
      return array.filter(item => (item as string).toLocaleLowerCase().includes(searchText))
    }
  }
}
