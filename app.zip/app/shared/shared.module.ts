import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AlertBoxComponent } from './Components/alert-box/alert-box.component';
import { ToasterComponent } from './Components/toaster/toaster.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommentsliderComponent } from './Components/commentslider/commentslider.component';
import { SingleSelectComponent } from './Components/single-select/single-select.component';
import { MaterialModule } from './material/material/material.module';
import { AutocompeleteMultiselectComponent } from './Components/autocompelete-multiselect/autocompelete-multiselect.component';
import { EmailDropdownComponentComponent } from './Components/email-dropdown-component/email-dropdown-component.component';
import { ChooserPipe } from './Pipes/chooser.pipe';
import { DateAgoPipe } from './Pipes/date-ago.pipe';
import { SearchPipe } from './Pipes/search.pipe';
import { ContentLoaderComponent } from './Components/content-loader/content-loader.component';
import { InfiniteScrollComponent } from './Components/infinite-scroll/infinite-scroll.component';
import { SelectWithSearchComponent } from './Components/select-with-search/select-with-search.component';
import { MultiSelectorComponent } from './Components/multi-selector/multi-selector.component';
import { NgxMaskModule} from 'ngx-mask';


@NgModule({
  declarations: [
    AlertBoxComponent,
    ToasterComponent,
    CommentsliderComponent,
    SingleSelectComponent,
    AutocompeleteMultiselectComponent,
    EmailDropdownComponentComponent,
    ChooserPipe,
    DateAgoPipe,
    SearchPipe,
    ContentLoaderComponent,
    InfiniteScrollComponent,
    SelectWithSearchComponent,
    MultiSelectorComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MaterialModule,
    NgxMaskModule.forRoot()
  ],
  exports:[
    FormsModule,
    ReactiveFormsModule,
    ChooserPipe,
    NgxMaskModule,
    ToasterComponent,
    AlertBoxComponent,
    SingleSelectComponent,
    CommentsliderComponent, 
    MaterialModule,
    AutocompeleteMultiselectComponent,
    EmailDropdownComponentComponent,
    DateAgoPipe,
    SearchPipe,
    ContentLoaderComponent,
    InfiniteScrollComponent,
    SelectWithSearchComponent,
    MultiSelectorComponent
  ]
})
export class SharedModule { }
